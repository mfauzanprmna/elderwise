<?php

namespace App\Support;

use App\Models\Lesson;
use App\Models\Module;
use App\Models\User;
use Illuminate\Support\Collection;

/**
 * Jalur belajar seorang peserta: urutan materi dari Modul 1 sampai akhir.
 *
 * Aturan utama: sebuah materi hanya bisa dibuka bila SEMUA materi sebelumnya
 * (di modul yang sama maupun modul sebelumnya) sudah selesai. Materi yang sudah selesai
 * selalu boleh dibuka lagi untuk ditinjau. Admin boleh membuka semuanya untuk pratinjau.
 */
class LearningPath
{
    /** @var Collection<int, Module> modul berurutan, lessons sudah dimuat */
    public Collection $modules;

    /** @var Collection<int, Lesson> seluruh materi dalam urutan belajar */
    public Collection $lessons;

    /** @var array<int, true> id materi yang sudah selesai */
    private array $completed;

    private bool $bypass;

    public function __construct(private User $user)
    {
        // Kolom isi (content/quiz) sengaja tidak dimuat: kerangka urutan belajar tidak membutuhkannya.
        $this->modules = Module::with('lessons:id,module_id,code,title,type,sort_order')->orderBy('sort_order')->get();
        $this->lessons = $this->modules->flatMap(fn (Module $m) => $m->lessons)->values();
        $this->completed = array_fill_keys(
            $user->lessonProgress()->whereNotNull('completed_at')->pluck('lesson_id')->all(),
            true
        );
        $this->bypass = $user->role === 'admin';
    }

    public function isCompleted(Lesson|int $lesson): bool
    {
        return isset($this->completed[$lesson instanceof Lesson ? $lesson->id : $lesson]);
    }

    /** @return array<int, int> */
    public function completedIds(): array
    {
        return array_keys($this->completed);
    }

    public function totalCount(): int
    {
        return $this->lessons->count();
    }

    /** Jumlah materi selesai yang masih ada di kurikulum. */
    public function completedCount(): int
    {
        return $this->lessons->filter(fn (Lesson $l) => $this->isCompleted($l))->count();
    }

    public function overallPercent(): int
    {
        return $this->totalCount() > 0 ? (int) round($this->completedCount() / $this->totalCount() * 100) : 0;
    }

    public function isUnlocked(Lesson $lesson): bool
    {
        if ($this->bypass || $this->isCompleted($lesson)) {
            return true;
        }

        foreach ($this->lessons as $candidate) {
            if ($candidate->id === $lesson->id) {
                return true;
            }
            if (! $this->isCompleted($candidate)) {
                return false;
            }
        }

        return false; // materi tidak termasuk dalam kurikulum
    }

    /** Materi pertama yang belum selesai ("posisi belajar" peserta saat ini). */
    public function frontier(): ?Lesson
    {
        return $this->lessons->first(fn (Lesson $l) => ! $this->isCompleted($l)) ?? $this->lessons->last();
    }

    public function modulePercent(Module $module): int
    {
        $m = $this->find($module);
        $count = $m->lessons->count();
        if ($count === 0) {
            return 0;
        }
        $done = $m->lessons->filter(fn (Lesson $l) => $this->isCompleted($l))->count();

        return (int) round($done / $count * 100);
    }

    public function isModuleComplete(Module $module): bool
    {
        $m = $this->find($module);

        return $m->lessons->isNotEmpty() && $m->lessons->every(fn (Lesson $l) => $this->isCompleted($l));
    }

    public function isModuleUnlocked(Module $module): bool
    {
        $m = $this->find($module);
        $first = $m->lessons->first();
        if ($first) {
            return $this->isUnlocked($first);
        }

        // Modul tanpa materi: terbuka bila semua modul sebelumnya tuntas.
        foreach ($this->modules as $other) {
            if ($other->id === $m->id) {
                return true;
            }
            if ($other->lessons->isNotEmpty() && ! $this->isModuleComplete($other)) {
                return false;
            }
        }

        return true;
    }

    /** Materi yang dibuka saat peserta masuk ke sebuah modul: yang belum selesai pertama, atau yang pertama. */
    public function resumeLessonFor(Module $module): ?Lesson
    {
        $m = $this->find($module);

        return $m->lessons->first(fn (Lesson $l) => ! $this->isCompleted($l)) ?? $m->lessons->first();
    }

    public function previous(Lesson $lesson): ?Lesson
    {
        $i = $this->lessons->search(fn (Lesson $l) => $l->id === $lesson->id);

        return ($i !== false && $i > 0) ? $this->lessons[$i - 1] : null;
    }

    public function next(Lesson $lesson): ?Lesson
    {
        $i = $this->lessons->search(fn (Lesson $l) => $l->id === $lesson->id);

        return ($i !== false && $i < $this->lessons->count() - 1) ? $this->lessons[$i + 1] : null;
    }

    public function moduleOf(Lesson $lesson): ?Module
    {
        return $this->modules->firstWhere('id', $lesson->module_id);
    }

    /** Apakah seluruh modul (yang berisi materi) sudah tuntas. */
    public function allModulesComplete(): bool
    {
        return $this->lessons->isNotEmpty()
            && $this->modules->every(fn (Module $m) => $m->lessons->isEmpty() || $this->isModuleComplete($m));
    }

    /** Data untuk alert "Selamat, Modul X selesai" (dipakai SweetAlert di browser). */
    public function moduleCompletionPayload(Module $module): array
    {
        $m = $this->find($module);
        $index = $this->modules->search(fn (Module $x) => $x->id === $m->id);
        $nextModule = $this->modules->slice(($index === false ? 0 : $index) + 1)->first(fn (Module $x) => $x->lessons->isNotEmpty());

        return [
            'number' => $m->number,
            'title' => $m->title,
            'badge' => $m->badge,
            'badge_icon' => $m->badgeIcon(),
            'badge_image' => $m->badgeImageUrl(),
            'next' => $nextModule ? [
                'number' => $nextModule->number,
                'title' => $nextModule->title,
                'url' => route('learning.show', ['module' => $nextModule->id]),
            ] : null,
            'all_done' => $this->allModulesComplete(),
            'dashboard_url' => route('dashboard'),
        ];
    }

    private function find(Module $module): Module
    {
        return $this->modules->firstWhere('id', $module->id) ?? $module->loadMissing('lessons');
    }
}
