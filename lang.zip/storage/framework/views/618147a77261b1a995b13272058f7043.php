<?php $__env->startSection('content'); ?>
    <div class="min-h-[calc(100vh-84px)] grid place-items-center px-5 py-12">
        <div class="card w-full max-w-md p-9 md:p-11">
            <div class="eyebrow">Lupa Kata Sandi</div>
            <h1 class="text-3xl mt-2 mb-2">Atur ulang kata sandi</h1>
            <p class="text-muted text-lg">Tenang, hal ini wajar terjadi. Masukkan email yang Anda pakai saat mendaftar. Kami akan memeriksanya, lalu mengirim tautan untuk membuat kata sandi baru.</p>

            <form method="POST" action="<?php echo e(route('password.email')); ?>" class="grid gap-5 mt-7">
                <?php echo csrf_field(); ?>
                <label class="form-label">
                    Email
                    <input class="form-input" name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="email" placeholder="nama@kampus.ac.id">
                </label>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red text-sm font-semibold" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="btn btn-primary w-full" data-loading-text="Memeriksa email…">Kirim Tautan</button>
            </form>

            <p class="text-muted text-base mt-6 mb-0">
                Mendaftar dengan Google? Anda tetap dapat membuat kata sandi di sini, atau cukup masuk dengan tombol Google.
            </p>

            <p class="text-center text-muted mt-6 mb-0 text-lg">
                <a class="text-blue-dark font-bold" href="<?php echo e(route('login')); ?>">Kembali ke halaman masuk</a>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>