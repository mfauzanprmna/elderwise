<?php $__env->startSection('content'); ?>
    <div class="min-h-[calc(100vh-84px)] grid place-items-center px-5 py-12">
        <div class="card w-full max-w-md p-9 md:p-11">
            <div class="eyebrow">Kata Sandi Baru</div>
            <h1 class="text-3xl mt-2 mb-2">Buat kata sandi baru</h1>
            <p class="text-muted text-lg">Gunakan minimal 8 karakter. Pilih kata sandi yang mudah Anda ingat namun sulit ditebak orang lain.</p>

            <form method="POST" action="<?php echo e(route('password.update')); ?>" class="grid gap-5 mt-7">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="token" value="<?php echo e($token); ?>">

                <label class="form-label">
                    Email
                    <input class="form-input" name="email" type="email" value="<?php echo e(old('email', $email)); ?>" required autocomplete="email" <?php if(filled(old('email', $email))): echo 'readonly'; endif; ?>>
                </label>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red text-sm font-semibold" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="form-label">
                    Kata sandi baru
                    <input class="form-input" name="password" type="password" required autofocus autocomplete="new-password">
                </label>

                <label class="form-label">
                    Ulangi kata sandi baru
                    <input class="form-input" name="password_confirmation" type="password" required autocomplete="new-password">
                </label>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red text-sm font-semibold" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="btn btn-primary w-full">Simpan Kata Sandi Baru</button>
            </form>

            <p class="text-center text-muted mt-6 mb-0 text-lg">
                <a class="text-blue-dark font-bold" href="<?php echo e(route('login')); ?>">Kembali ke halaman masuk</a>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>