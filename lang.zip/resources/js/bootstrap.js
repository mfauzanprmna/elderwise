// ElderWiSE frontend bootstrap.
