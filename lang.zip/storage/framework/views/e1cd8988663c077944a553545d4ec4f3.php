<?php $__env->startSection('content'); ?>
    <?php $avatar = $user->avatarUrl(); ?>
    <div class="max-w-3xl mx-auto px-5 md:px-8 py-10 md:py-14">
        <div class="eyebrow">Akun Saya</div>
        <h1 class="text-3xl md:text-4xl mt-2 mb-2">Pengaturan Akun</h1>
        <p class="text-muted text-lg m-0">Atur nama dan foto profil Anda.</p>

        <nav class="ew-tabs" aria-label="Pengaturan akun">
            <a href="<?php echo e(route('profile.edit')); ?>" aria-current="page">Profil</a>
            <a href="<?php echo e(route('profile.password')); ?>">Ganti Kata Sandi</a>
        </nav>

        <div class="card p-8 md:p-10 mt-6">
            <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data" class="grid gap-7">
                <?php echo csrf_field(); ?>

                <div class="ew-photo-row">
                    <span id="avatar-preview" class="ew-avatar ew-avatar-lg" aria-hidden="true">
                        <?php echo e($user->initials()); ?>

                        <?php if($avatar): ?><img src="<?php echo e($avatar); ?>" alt="" referrerpolicy="no-referrer" onerror="this.remove()"><?php endif; ?>
                    </span>
                    <div>
                        <label class="form-label" for="avatar">Foto profil</label>
                        <input id="avatar" class="form-input" type="file" name="avatar"
                               accept="image/png,image/jpeg,image/webp" data-max-kb="2048" data-avatar-preview="#avatar-preview">
                        <p class="ew-hint">Format JPG, PNG, atau WebP, maksimal 2 MB. Foto ini tampil di pojok kanan atas.</p>
                        <?php if($user->avatar_url && ! $user->avatar_path): ?>
                            <p class="ew-hint">Saat ini memakai foto dari akun Google Anda. Unggah foto di sini untuk menggantinya.</p>
                        <?php endif; ?>
                        <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red text-sm font-semibold mt-1" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php if($user->avatar_path): ?>
                            <label class="flex items-center gap-2.5 font-semibold text-base mt-3">
                                <input type="checkbox" name="remove_avatar" value="1" class="w-5.5 h-5.5">
                                Hapus foto saya
                            </label>
                        <?php endif; ?>
                    </div>
                </div>

                <div>
                    <label class="form-label" for="name">Nama lengkap</label>
                    <input id="name" class="form-input" name="name" value="<?php echo e(old('name', $user->name)); ?>" required maxlength="120" autocomplete="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red text-sm font-semibold mt-1" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="form-label" for="email">Email</label>
                    <input id="email" class="form-input" type="email" value="<?php echo e($user->email); ?>" readonly aria-describedby="email-hint" style="background:#f4f7fb">
                    <p id="email-hint" class="ew-hint">Email dipakai untuk masuk dan tidak dapat diubah sendiri. Hubungi penyelenggara bila perlu mengubahnya.</p>
                </div>

                <button class="btn btn-primary" data-loading-text="Menyimpan…">Simpan Perubahan</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/profile/edit.blade.php ENDPATH**/ ?>