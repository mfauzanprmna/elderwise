<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-5 md:px-10 py-10 md:py-14">

        
        <div class="rounded-3xl p-7 md:p-9 mb-10 text-white relative overflow-hidden"
             style="background:linear-gradient(135deg, var(--color-navy) 0%, var(--color-blue-dark) 55%, var(--color-blue) 100%)">

            
            <div class="absolute w-72 h-72 rounded-full bg-white/5 -right-16 -top-20 pointer-events-none"></div>
            <div class="absolute w-44 h-44 rounded-full bg-white/5 -left-10 -bottom-16 pointer-events-none"></div>

            <div class="relative flex flex-wrap items-center gap-7">
                <div class="w-20 h-20 md:w-24 md:h-24 rounded-full bg-white/10 border-2 border-white/25 grid place-items-center text-4xl md:text-5xl shrink-0">
                    <?php echo e($rank['icon']); ?>

                </div>

                <div class="flex-1 min-w-[260px]">
                    <p class="text-blue-100 text-base m-0" style="color:#c3d8f5">Selamat datang kembali,</p>
                    <h1 class="text-white text-2xl md:text-3xl my-1"><?php echo e(auth()->user()->name); ?></h1>
                    <p class="m-0 text-lg font-bold" style="color:#ffd97a"><?php echo e($rank['name']); ?></p>
                </div>

                <div class="w-full md:w-auto md:min-w-[320px]">
                    <div class="flex flex-wrap justify-between gap-x-3 gap-y-0.5 text-sm font-semibold mb-1.5" style="color:#c3d8f5">
                        <span class="whitespace-nowrap"><?php echo e($totalXp); ?> XP</span>
                        <span class="whitespace-nowrap"><?php echo e($rank['next_name'] ? $rank['next_name'] . ' pada ' . $rank['next_min'] . ' XP' : 'Rank tertinggi!'); ?></span>
                    </div>
                    <div class="h-3.5 rounded-full bg-white/15 overflow-hidden">
                        <div class="h-full rounded-full" style="width:<?php echo e($rank['progress_pct']); ?>%; background:linear-gradient(90deg, #ffd97a, #ffb64c)"></div>
                    </div>
                </div>
            </div>

            <div class="relative flex flex-wrap gap-4 md:gap-8 mt-7 pt-6 border-t border-white/15">
                <div>
                    <b class="block text-2xl md:text-3xl leading-tight"><?php echo e($done); ?>/<?php echo e($total); ?></b>
                    <span class="text-sm" style="color:#c3d8f5">Materi selesai</span>
                </div>
                <div>
                    <b class="block text-2xl md:text-3xl leading-tight"><?php echo e($modulesCompletedCount); ?>/<?php echo e($modules->count()); ?></b>
                    <span class="text-sm" style="color:#c3d8f5">Modul tuntas</span>
                </div>
                <div>
                    <b class="block text-2xl md:text-3xl leading-tight"><?php echo e($totalXp); ?></b>
                    <span class="text-sm" style="color:#c3d8f5">Total XP</span>
                </div>
            </div>
        </div>

        
        <div class="mb-10">
            <h2 class="text-2xl mb-4">Koleksi Lencana</h2>
            <div class="flex flex-wrap gap-4">
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $ids = $m->lessons->pluck('id')->all();
                        $isModuleDone = count($ids) > 0 && count(array_diff($ids, $completed)) === 0;
                    ?>
                    <div class="flex flex-col items-center gap-2 w-24 text-center" title="<?php echo e($m->badge); ?>">
                        <?php if (isset($component)) { $__componentOriginal050558fa169e8fab1a632431d1ec4e8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal050558fa169e8fab1a632431d1ec4e8a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge-medal','data' => ['module' => $m,'state' => $isModuleDone ? 'done' : 'locked','size' => 64]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge-medal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['module' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m),'state' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isModuleDone ? 'done' : 'locked'),'size' => 64]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal050558fa169e8fab1a632431d1ec4e8a)): ?>
<?php $attributes = $__attributesOriginal050558fa169e8fab1a632431d1ec4e8a; ?>
<?php unset($__attributesOriginal050558fa169e8fab1a632431d1ec4e8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal050558fa169e8fab1a632431d1ec4e8a)): ?>
<?php $component = $__componentOriginal050558fa169e8fab1a632431d1ec4e8a; ?>
<?php unset($__componentOriginal050558fa169e8fab1a632431d1ec4e8a); ?>
<?php endif; ?>
                        <span class="text-xs font-semibold leading-tight <?php echo e($isModuleDone ? 'text-navy' : 'text-muted'); ?>">
                            <?php echo e($m->badge); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <h2 class="text-2xl mb-4">Peta Belajar</h2>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $moduleIds = $m->lessons->pluck('id')->all();
                    $moduleDone = $m->lessons->whereIn('id', $completed)->count();
                    $modulePct = $m->lessons->count() ? round($moduleDone / $m->lessons->count() * 100) : 0;
                    $isModuleDone = count($moduleIds) > 0 && $moduleDone === count($moduleIds);
                    $isStarted = $moduleDone > 0;
                ?>
                <article class="card p-6 flex flex-col relative overflow-hidden <?php echo e($isModuleDone ? 'ring-2' : ''); ?>"
                          style="<?php echo e($isModuleDone ? 'box-shadow:0 10px 28px rgba(240,180,41,.18); border-color:#f0d896;' : ''); ?>">

                    <?php if($isModuleDone): ?>
                        <span class="absolute top-0 right-0 text-xs font-extrabold text-white px-3 py-1.5 rounded-bl-xl"
                              style="background:linear-gradient(135deg, #f0b429, #d98e04)">✓ TUNTAS</span>
                    <?php endif; ?>

                    <div class="flex items-center gap-4">
                        <?php if (isset($component)) { $__componentOriginal050558fa169e8fab1a632431d1ec4e8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal050558fa169e8fab1a632431d1ec4e8a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge-medal','data' => ['module' => $m,'state' => $isModuleDone ? 'done' : ($isStarted ? 'progress' : 'locked'),'size' => 56]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge-medal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['module' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m),'state' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isModuleDone ? 'done' : ($isStarted ? 'progress' : 'locked')),'size' => 56]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal050558fa169e8fab1a632431d1ec4e8a)): ?>
<?php $attributes = $__attributesOriginal050558fa169e8fab1a632431d1ec4e8a; ?>
<?php unset($__attributesOriginal050558fa169e8fab1a632431d1ec4e8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal050558fa169e8fab1a632431d1ec4e8a)): ?>
<?php $component = $__componentOriginal050558fa169e8fab1a632431d1ec4e8a; ?>
<?php unset($__componentOriginal050558fa169e8fab1a632431d1ec4e8a); ?>
<?php endif; ?>
                        <div class="flex-1">
                            <span class="text-muted text-sm font-bold">Modul <?php echo e($m->number); ?></span>
                            <div class="h-2 rounded-full bg-blue-tint/60 overflow-hidden mt-1.5">
                                <div class="h-full rounded-full" style="width:<?php echo e($modulePct); ?>%; background:<?php echo e($isModuleDone ? 'linear-gradient(90deg,' . $m->badgeColor()['to'] . ',' . $m->badgeColor()['border'] . ')' : 'var(--color-blue)'); ?>"></div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-1 py-4">
                        <h2 class="text-2xl leading-snug mt-1 mb-1"><?php echo e($m->title); ?></h2>
                        <h3 class="text-blue-dark font-bold text-base mb-3">&ldquo;<?php echo e($m->slogan); ?>&rdquo;</h3>
                        <p class="text-ink text-base min-h-[4rem]"><?php echo e($m->description); ?></p>
                        <div class="flex flex-wrap gap-2 mt-3">
                            <span class="bg-blue-tint text-navy text-sm font-semibold rounded-full px-3 py-1.5"><?php echo e($m->lessons->count()); ?> lessons</span>
                        </div>
                    </div>

                    <a class="btn w-full <?php echo e($isModuleDone ? 'btn-ghost' : 'btn-primary'); ?>" href="<?php echo e(route('learning.show', $m)); ?>">
                        <?php echo e($isModuleDone ? 'Lihat Kembali' : ($isStarted ? 'Lanjutkan' : 'Mulai Modul')); ?> →
                    </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <?php if($allCompleted): ?>
            <div class="mt-10 flex flex-wrap items-center gap-6 rounded-2xl p-7 md:p-8 text-white shadow-elder-lg relative overflow-hidden"
                 style="background:linear-gradient(135deg, #8a5d00, #f0b429)">
                <div class="text-5xl leading-none">🎓</div>
                <div class="flex-1 min-w-[260px]">
                    <h2 class="text-white text-2xl mb-1.5">Selamat, semua modul telah selesai!</h2>
                    <p class="m-0 text-lg" style="color:#fff3d6">
                        Bapak/Ibu berhak mendapatkan sertifikat kelulusan <?php echo e($site->site_name); ?>. File PDF berisi 2 halaman: sertifikat dan rincian materi dengan total <?php echo e($modules->count() * \App\Models\Module::TRAINING_HOURS); ?> JP (Jam Pelatihan).
                    </p>
                </div>
                <div>
                    <?php if($certificate): ?>
                        <a class="btn bg-white text-amber hover:bg-amber-tint" href="<?php echo e(route('certificate.download')); ?>">
                            Unduh Sertifikat (PDF, 2 halaman)
                        </a>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('certificate.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn bg-white text-amber hover:bg-amber-tint">Buat Sertifikat Saya</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/learning/dashboard.blade.php ENDPATH**/ ?>