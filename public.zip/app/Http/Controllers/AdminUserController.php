<?php
namespace App\Http\Controllers;

use App\Models\Certificate;
use App\Models\Lesson;
use App\Models\LessonProgress;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class AdminUserController extends Controller
{
    /** Peran yang tersedia. 'learner' = peserta (nilai yang dipakai saat registrasi). */
    public const ROLES = ['learner' => 'Peserta', 'admin' => 'Admin'];

    /** Pesan validasi berbahasa Indonesia untuk form pengguna. */
    private function messages(): array
    {
        return [
            'name.required' => 'Nama wajib diisi.',
            'name.max' => 'Nama terlalu panjang (maksimal 120 karakter).',
            'email.required' => 'Email wajib diisi.',
            'email.email' => 'Format email tidak valid.',
            'email.unique' => 'Email ini sudah dipakai akun lain.',
            'role.required' => 'Peran wajib dipilih.',
            'role.in' => 'Peran yang dipilih tidak valid.',
            'password.required' => 'Kata sandi wajib diisi.',
            'password.min' => 'Kata sandi minimal 8 karakter.',
            'password.confirmed' => 'Pengulangan kata sandi tidak sama.',
        ];
    }

    public function index(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        $role = $request->query('role');

        $users = User::query()
            ->when($q !== '', fn ($query) => $query->where(
                fn ($w) => $w->where('name', 'like', "%{$q}%")->orWhere('email', 'like', "%{$q}%")
            ))
            ->when(array_key_exists((string) $role, self::ROLES), fn ($query) => $query->where('role', $role))
            ->withCount(['lessonProgress as done_count' => fn ($p) => $p->whereNotNull('completed_at')])
            ->withSum(['lessonProgress as xp_total' => fn ($p) => $p->whereNotNull('completed_at')], 'xp')
            ->with('certificate')
            ->orderBy('name')
            ->paginate(10)
            ->withQueryString();

        return view('admin.users.index', [
            'users' => $users,
            'q' => $q,
            'role' => array_key_exists((string) $role, self::ROLES) ? $role : '',
            'totalLessons' => Lesson::count(),
            'countAll' => User::count(),
            'countLearners' => User::where('role', '!=', 'admin')->count(),
            'countAdmins' => User::where('role', 'admin')->count(),
        ]);
    }

    public function create()
    {
        return view('admin.users.form', ['user' => new User(['role' => 'learner']), 'roles' => self::ROLES]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:190', 'unique:users,email'],
            'role' => ['required', Rule::in(array_keys(self::ROLES))],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ], $this->messages());

        User::create($data); // password di-hash otomatis oleh cast 'hashed' pada model User

        return redirect()->route('admin.users.index')->with('success', 'Pengguna "' . $data['name'] . '" berhasil ditambahkan.');
    }

    public function edit(User $user)
    {
        $user->loadCount(['lessonProgress as done_count' => fn ($p) => $p->whereNotNull('completed_at')]);
        $user->loadSum(['lessonProgress as xp_total' => fn ($p) => $p->whereNotNull('completed_at')], 'xp');
        $user->load('certificate');

        return view('admin.users.form', [
            'user' => $user,
            'roles' => self::ROLES,
            'totalLessons' => Lesson::count(),
        ]);
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:190', Rule::unique('users', 'email')->ignore($user->id)],
            'role' => ['required', Rule::in(array_keys(self::ROLES))],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
        ], $this->messages());

        // Admin tidak boleh menurunkan perannya sendiri (mencegah sistem tanpa admin sama sekali).
        if ($user->id === $request->user()->id && $data['role'] !== 'admin') {
            return back()->withErrors(['role' => 'Peran akun Anda sendiri tidak bisa diturunkan dari Admin. Minta admin lain jika perlu.'])->withInput();
        }

        if (blank($data['password'] ?? null)) {
            unset($data['password']); // kosong = kata sandi tidak diubah
        }

        $user->update($data);

        return redirect()->route('admin.users.index')->with('success', 'Data pengguna "' . $user->name . '" berhasil diperbarui.');
    }

    public function destroy(Request $request, User $user)
    {
        if ($user->id === $request->user()->id) {
            return redirect()->route('admin.users.index')->with('error', 'Akun yang sedang Anda pakai tidak bisa dihapus.');
        }

        $name = $user->name;

        DB::transaction(function () use ($user) {
            LessonProgress::where('user_id', $user->id)->delete();
            Certificate::where('user_id', $user->id)->delete();
            $user->delete();
        });

        return redirect()->route('admin.users.index')->with('success', 'Pengguna "' . $name . '" beserta progres belajarnya telah dihapus.');
    }
}
