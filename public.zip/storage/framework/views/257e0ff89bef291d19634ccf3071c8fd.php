<?php $__env->startSection('content'); ?><div class="auth-wrap"><div class="auth-card"><div class="eyebrow">START YOUR JOURNEY</div><h1>Buat akun ElderWiSE</h1><p class="muted">Tidak perlu sempurna. Mulai dari satu langkah.</p><form method="POST" action="<?php echo e(route('register.store')); ?>" class="form-stack"><?php echo csrf_field(); ?><label>Nama<input name="name" value="<?php echo e(old('name')); ?>" required></label><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><label>Email<input name="email" type="email" value="<?php echo e(old('email')); ?>" required></label><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><label>Kata sandi<input name="password" type="password" required></label><label>Ulangi kata sandi<input name="password_confirmation" type="password" required></label><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><button class="btn btn-primary full">Buat Akun</button></form><p class="auth-foot">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk</a></p></div></div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/auth/register.blade.php ENDPATH**/ ?>