<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Throwable;

class Lesson extends Model
{
    /**
     * Batas bawah kecepatan membaca yang dipakai untuk menentukan lama minimal di tiap bagian:
     * 6 kata/detik = 360 kata/menit, jauh lebih cepat dari pembaca biasa, jadi pembaca sungguhan
     * tidak akan tertahan. Orang yang sekadar menggulir cepat ke bawah akan tertahan.
     */
    public const WORDS_PER_SECOND = 6;

    /** Sekitar berapa kata per bagian (checkpoint), dan batas jumlah bagian per materi. */
    public const WORDS_PER_SECTION = 140;
    public const MAX_SECTIONS = 8;

    /** Materi PDF: lama minimal (detik) per bagian. Jumlah bagian mengikuti perkiraan jumlah halaman. */
    public const PDF_SECONDS_PER_SECTION = 15;

    protected $fillable = ['module_id','code','title','type','content','pdf_path','quiz','sort_order'];
    protected $casts = ['quiz' => 'array'];

    private ?array $readingPlanCache = null;

    public function module(){ return $this->belongsTo(Module::class); }
    public function progress(){ return $this->hasMany(LessonProgress::class); }

    public function isPdf(): bool
    {
        return $this->type === 'pdf' && filled($this->pdf_path);
    }

    public function hasQuiz(): bool
    {
        return is_array($this->quiz) && count($this->quiz) > 0;
    }

    /**
     * Isi materi siap tampil. Materi hasil editor (HTML) dipakai apa adanya; materi lama yang
     * tersimpan sebagai teks polos (baris baru biasa atau tulisan \n literal) diubah jadi paragraf.
     */
    public function renderedContent(): string
    {
        $content = (string) $this->content;
        if ($content === '' || preg_match('/<[a-z][\s\S]*>/i', $content)) {
            return $content;
        }

        $paragraphs = preg_split('/(?:\\\\n|\r?\n){2,}/', $content);

        return collect($paragraphs)
            ->map(fn ($p) => trim($p))
            ->filter()
            ->map(fn ($p) => '<p>' . preg_replace('/(?:\\\\n|\r?\n)/', '<br>', e($p)) . '</p>')
            ->implode('');
    }

    /**
     * Rencana "checkpoint" membaca untuk materi ini.
     *
     * Materi dibagi menjadi beberapa bagian. Peserta harus melewati tiap bagian secara berurutan
     * (bagian harus benar-benar tampil di layar dan ada waktu baca minimal) sebelum materi
     * dianggap selesai. Server dan browser memakai rencana yang sama.
     *
     * @return array{mode:string, html:string, sections:array<int, array{words:int, dwell:int}>}
     *         mode 'text' | 'pdf'; html = isi materi + penanda checkpoint; sections = daftar bagian
     *         (kosong = tidak ada yang perlu dibaca, mis. materi hanya kuis)
     */
    public function readingPlan(): array
    {
        return $this->readingPlanCache ??= ($this->isPdf() ? $this->pdfPlan() : $this->textPlan());
    }

    /** Jumlah checkpoint yang harus dilewati. */
    public function checkpointTotal(): int
    {
        return count($this->readingPlan()['sections']);
    }

    private function dwellFor(int $words): int
    {
        return max(3, min(60, (int) ceil($words / self::WORDS_PER_SECOND)));
    }

    // ---------------------------------------------------------------- PDF

    private function pdfPlan(): array
    {
        $count = max(3, min(self::MAX_SECTIONS + 2, $this->estimatePdfPages()));
        $sections = array_fill(0, $count, ['words' => 0, 'dwell' => self::PDF_SECONDS_PER_SECTION]);

        return ['mode' => 'pdf', 'html' => '', 'sections' => $sections];
    }

    /** Perkiraan jumlah halaman PDF (hitung objek /Type /Page). Untuk PDF terkompresi hasilnya bisa 0 -> dipakai batas minimum. */
    private function estimatePdfPages(): int
    {
        try {
            $disk = Storage::disk('public');
            if (! $disk->exists($this->pdf_path)) {
                return 0;
            }
            $path = $disk->path($this->pdf_path);
            $key = 'lesson.pdfpages.' . $this->id . '.' . @filemtime($path);

            return (int) Cache::remember($key, 86400, function () use ($path) {
                $data = @file_get_contents($path);

                return $data === false ? 0 : (int) preg_match_all('#/Type\s*/Page(?![A-Za-z])#', $data);
            });
        } catch (Throwable $e) {
            return 0;
        }
    }

    // ---------------------------------------------------------------- Teks

    private function textPlan(): array
    {
        $html = $this->renderedContent();
        $hasMedia = (bool) preg_match('/<(img|table|iframe|video|figure)\b/i', $html);

        if (trim(html_entity_decode(strip_tags($html))) === '' && ! $hasMedia) {
            return ['mode' => 'text', 'html' => $html, 'sections' => []];
        }

        try {
            return $this->splitIntoSections($html);
        } catch (Throwable $e) {
            report($e);

            // Cadangan: satu bagian untuk seluruh materi, penanda di akhir.
            $words = $this->countWords(strip_tags($html));

            return [
                'mode' => 'text',
                'html' => $html . self::marker(1, 1),
                'sections' => [['words' => $words, 'dwell' => $this->dwellFor($words)]],
            ];
        }
    }

    private function splitIntoSections(string $html): array
    {
        $previous = libxml_use_internal_errors(true);
        $dom = new \DOMDocument('1.0', 'UTF-8');
        $loaded = $dom->loadHTML('<?xml encoding="UTF-8"><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        $root = $dom->getElementsByTagName('div')->item(0);
        if (! $loaded || ! $root) {
            throw new \RuntimeException('Gagal membaca isi materi.');
        }

        $children = iterator_to_array($root->childNodes, false);

        // Bobot tiap blok: jumlah kata (gambar/tabel dihitung minimal 25 supaya ikut membentuk bagian).
        $info = [];
        $totalWords = 0;
        $totalWeight = 0;
        $contentNodes = 0;
        foreach ($children as $i => $node) {
            $words = $this->countWords($node->textContent ?? '');
            $isMedia = $node instanceof \DOMElement && (
                in_array(strtolower($node->nodeName), ['img', 'figure', 'table', 'iframe', 'video'], true)
                || $node->getElementsByTagName('img')->length > 0
            );
            $weight = max($words, $isMedia ? 25 : 0);
            $info[$i] = ['words' => $words, 'weight' => $weight];
            $totalWords += $words;
            $totalWeight += $weight;
            if ($weight > 0) {
                $contentNodes++;
            }
        }

        if ($totalWeight === 0) {
            return ['mode' => 'text', 'html' => $html, 'sections' => []];
        }

        $target = max(1, min(self::MAX_SECTIONS, (int) ceil($totalWords / self::WORDS_PER_SECTION), $contentNodes));
        $perSection = $totalWeight / $target;

        // Blok berisi terakhir tidak boleh menutup bagian sendiri: penanda akhir selalu ditambahkan setelahnya.
        $lastContentIndex = 0;
        foreach ($info as $i => $row) {
            if ($row['weight'] > 0) {
                $lastContentIndex = $i;
            }
        }

        // Tentukan setelah blok ke-berapa tiap bagian berakhir (bagian terakhir berakhir di akhir materi).
        $cutAfter = [];
        $sections = [];
        $accWeight = 0;
        $secWords = 0;
        foreach ($children as $i => $node) {
            $accWeight += $info[$i]['weight'];
            $secWords += $info[$i]['words'];

            $closed = count($cutAfter) + 1;
            if ($info[$i]['weight'] > 0 && $i < $lastContentIndex && $closed < $target && $accWeight >= $perSection * $closed) {
                $cutAfter[] = $i;
                $sections[] = ['words' => $secWords, 'dwell' => $this->dwellFor($secWords)];
                $secWords = 0;
            }
        }
        $sections[] = ['words' => $secWords, 'dwell' => $this->dwellFor($secWords)];

        $total = count($sections);

        // Sisipkan penanda checkpoint di akhir tiap bagian.
        foreach ($cutAfter as $n => $i) {
            $marker = $this->markerNode($dom, $n + 1, $total);
            $root->insertBefore($marker, $children[$i]->nextSibling);
        }
        $root->appendChild($this->markerNode($dom, $total, $total));

        $out = '';
        foreach ($root->childNodes as $child) {
            $out .= $dom->saveHTML($child);
        }

        return ['mode' => 'text', 'html' => $out, 'sections' => $sections];
    }

    private function countWords(string $text): int
    {
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? '');

        return $text === '' ? 0 : count(explode(' ', $text));
    }

    private static function label(int $index, int $total): string
    {
        return $index === $total ? 'Akhir materi' : "Bagian {$index} dari {$total}";
    }

    private static function marker(int $index, int $total): string
    {
        $label = self::label($index, $total);

        return '<div class="ew-checkpoint" data-checkpoint="' . $index . '" data-total="' . $total . '" role="separator" aria-label="' . $label . '"><span>' . $label . '</span></div>';
    }

    private function markerNode(\DOMDocument $dom, int $index, int $total): \DOMElement
    {
        $el = $dom->createElement('div');
        $el->setAttribute('class', 'ew-checkpoint');
        $el->setAttribute('data-checkpoint', (string) $index);
        $el->setAttribute('data-total', (string) $total);
        $el->setAttribute('role', 'separator');
        $el->setAttribute('aria-label', self::label($index, $total));
        $el->appendChild($dom->createElement('span', self::label($index, $total)));

        return $el;
    }
}
