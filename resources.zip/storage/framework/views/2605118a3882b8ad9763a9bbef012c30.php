<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto px-5 md:px-10 py-10 md:py-14">
        <div class="eyebrow">Admin · <?php echo e($module->exists ? 'Edit Modul' : 'Modul Baru'); ?></div>
        <h1 class="text-3xl md:text-4xl mt-2 mb-1"><?php echo e($module->exists ? 'Edit modul' : 'Buat modul baru'); ?></h1>
        <p class="text-muted text-lg mb-7">Nomor modul dibuat otomatis. Lencana modul diatur di bagian bawah.</p>

        <?php if($errors->any()): ?>
            <div class="bg-red-tint text-red rounded-xl px-5 py-4 mb-6">
                <strong>Periksa kembali:</strong>
                <ul class="mt-2 ml-5 list-disc">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" id="module-form"
              action="<?php echo e($module->exists ? route('admin.modules.update', $module) : route('admin.modules.store')); ?>" class="grid gap-5">
            <?php echo csrf_field(); ?>
            <?php if($module->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="grid sm:grid-cols-2 gap-5">
                <label class="form-label">
                    Nomor Modul
                    <input type="number" value="<?php echo e(old('number', $module->number)); ?>" readonly class="form-input bg-bg cursor-not-allowed">
                    <small class="text-muted font-normal">Otomatis: modul terakhir + 1.</small>
                </label>
                <label class="form-label">
                    Urutan Tampil
                    <input type="number" value="<?php echo e(old('sort_order', $module->sort_order ?: $module->number)); ?>" readonly class="form-input bg-bg cursor-not-allowed">
                </label>
            </div>

            <label class="form-label">Judul Modul
                <input class="form-input" name="title" value="<?php echo e(old('title', $module->title)); ?>" required>
            </label>
            <label class="form-label">Slogan / Tagline
                <input class="form-input" name="slogan" value="<?php echo e(old('slogan', $module->slogan)); ?>" required>
            </label>
            <label class="form-label">Deskripsi
                <textarea class="form-input min-h-[54px]" name="description" rows="5"><?php echo e(old('description', $module->description)); ?></textarea>
            </label>

            
            <?php
                $currentColor = old('badge_color', $module->badge_color ?: 'gold');
                $currentIcon = old('badge_icon', $module->badge_icon);
                $emojiChoices = ['🌱','🤝','🔍','✍️','🤖','🏆','⭐','🚀','📚','💡','🛡️','🎯'];
            ?>
            <div class="border-2 border-line-strong rounded-2xl p-5 md:p-6 bg-white">
                <h2 class="text-xl mb-1">Lencana Modul</h2>
                <p class="text-muted text-base mb-5">Lencana diterima peserta saat seluruh materi modul ini selesai. Pilih emoji atau unggah logo sendiri.</p>

                <div class="grid md:grid-cols-[170px_1fr] gap-6 items-start">
                    
                    <div class="grid place-items-center gap-2 bg-bg rounded-2xl p-4">
                        <div id="badge-preview" class="rounded-full grid place-items-center border-2 overflow-hidden shadow-elder"
                             style="width:96px;height:96px;font-size:43px"></div>
                        <span id="badge-preview-name" class="text-sm font-bold text-navy text-center leading-tight">Nama lencana</span>
                        <span class="text-xs text-muted">Pratinjau (terbuka)</span>
                    </div>

                    <div class="grid gap-5">
                        <label class="form-label">Nama Lencana
                            <input class="form-input" name="badge" id="badge-name" value="<?php echo e(old('badge', $module->badge)); ?>" placeholder="Contoh: Digital Explorer">
                        </label>

                        <div class="grid gap-2">
                            <label class="form-label" for="badge-icon">Ikon (emoji)</label>
                            <input class="form-input" name="badge_icon" id="badge-icon" value="<?php echo e($currentIcon); ?>" maxlength="8" placeholder="Ketik atau pilih emoji di bawah">
                            <div class="flex flex-wrap gap-2" role="group" aria-label="Pilihan emoji cepat">
                                <?php $__currentLoopData = $emojiChoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emoji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" data-emoji="<?php echo e($emoji); ?>"
                                            class="emoji-pick w-12 h-12 rounded-xl border-2 border-line-strong bg-white text-2xl cursor-pointer hover:border-blue"><?php echo e($emoji); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="grid gap-2">
                            <label class="form-label" for="badge-image">Logo sendiri (opsional)</label>
                            <input type="file" name="badge_image" id="badge-image" accept="image/png,image/jpeg,image/webp" class="form-input">
                            <small class="text-muted">PNG/JPG/WebP, maksimal 2 MB. Jika logo diunggah, logo dipakai menggantikan emoji. Latar transparan (PNG) paling bagus.</small>
                            <?php if($module->badge_image): ?>
                                <div class="flex items-center gap-3 mt-1">
                                    <img src="<?php echo e($module->badgeImageUrl()); ?>" alt="Logo lencana saat ini" class="w-12 h-12 object-contain rounded-lg border-2 border-line bg-white p-1">
                                    <label class="flex items-center gap-2 cursor-pointer font-semibold text-base">
                                        <input type="checkbox" name="remove_badge_image" value="1" id="badge-remove" class="w-5 h-5" <?php if(old('remove_badge_image')): echo 'checked'; endif; ?>>
                                        Hapus logo ini (kembali ke emoji)
                                    </label>
                                </div>
                            <?php endif; ?>
                        </div>

                        <fieldset class="grid gap-2">
                            <legend class="font-bold text-lg text-navy mb-1">Warna medali</legend>
                            <div class="flex flex-wrap gap-4">
                                <?php $__currentLoopData = \App\Models\Module::BADGE_COLORS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex flex-col items-center gap-1.5 cursor-pointer">
                                        <input type="radio" name="badge_color" value="<?php echo e($key); ?>" class="peer sr-only badge-color-radio" <?php if($currentColor === $key): echo 'checked'; endif; ?>>
                                        <span class="w-12 h-12 rounded-full border-2 peer-checked:ring-4 peer-checked:ring-blue/40 peer-focus-visible:ring-4 peer-focus-visible:ring-blue"
                                              style="background:linear-gradient(135deg,<?php echo e($col['from']); ?>,<?php echo e($col['to']); ?>);border-color:<?php echo e($col['border']); ?>"></span>
                                        <span class="text-sm font-semibold text-ink"><?php echo e($col['label']); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>

            <div class="flex justify-end gap-3 mt-2">
                <a class="btn btn-ghost" href="<?php echo e(route('admin.modules.index')); ?>">Batal</a>
                <button class="btn btn-primary"><?php echo e($module->exists ? 'Simpan Perubahan' : 'Buat Modul & Kelola Materi →'); ?></button>
            </div>
        </form>
    </div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const preview = document.getElementById('badge-preview');
    const previewName = document.getElementById('badge-preview-name');
    const nameInput = document.getElementById('badge-name');
    const iconInput = document.getElementById('badge-icon');
    const fileInput = document.getElementById('badge-image');
    const removeBox = document.getElementById('badge-remove');
    const colors = <?php echo json_encode(collect(\App\Models\Module::BADGE_COLORS)->map(fn ($c) => ['from' => $c['from'], 'to' => $c['to'], 'border' => $c['border']])) ?>;
    const existingImage = <?php echo json_encode($module->badgeImageUrl(), 15, 512) ?>;
    const fallbackIcon = <?php echo json_encode($module->exists ? $module->badgeIcon() : '🎯', 15, 512) ?>;
    let uploadedUrl = null;

    function render() {
        const key = (document.querySelector('.badge-color-radio:checked') || {}).value || 'gold';
        const c = colors[key];
        preview.style.background = `linear-gradient(135deg, ${c.from}, ${c.to})`;
        preview.style.borderColor = c.border;

        let imgSrc = uploadedUrl;
        if (!imgSrc && existingImage && !(removeBox && removeBox.checked)) imgSrc = existingImage;

        preview.innerHTML = '';
        if (imgSrc) {
            const img = document.createElement('img');
            img.src = imgSrc;
            img.alt = '';
            img.style.cssText = 'width:68%;height:68%;object-fit:contain';
            preview.appendChild(img);
        } else {
            const span = document.createElement('span');
            span.textContent = iconInput.value.trim() || fallbackIcon;
            preview.appendChild(span);
        }
        previewName.textContent = nameInput.value.trim() || 'Nama lencana';
    }

    fileInput.addEventListener('change', function () {
        if (uploadedUrl) URL.revokeObjectURL(uploadedUrl);
        uploadedUrl = this.files && this.files[0] ? URL.createObjectURL(this.files[0]) : null;
        render();
    });
    document.querySelectorAll('.emoji-pick').forEach(btn => btn.addEventListener('click', function () {
        iconInput.value = this.dataset.emoji;
        // memilih emoji = tidak memakai logo unggahan yang baru dipilih
        fileInput.value = '';
        if (uploadedUrl) { URL.revokeObjectURL(uploadedUrl); uploadedUrl = null; }
        if (removeBox) removeBox.checked = true;
        render();
    }));
    [nameInput, iconInput].forEach(el => el.addEventListener('input', render));
    document.querySelectorAll('.badge-color-radio').forEach(r => r.addEventListener('change', render));
    if (removeBox) removeBox.addEventListener('change', render);
    render();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views\admin\modules\form.blade.php ENDPATH**/ ?>