/*
 * ElderWiSE — alur belajar otomatis.
 *
 * Tidak ada tombol "tandai selesai". Materi dibagi menjadi beberapa bagian (checkpoint).
 * Sebuah checkpoint dihitung lewat bila:
 *   1. penandanya benar-benar sempat tampil di layar (tidak cukup melompat ke bawah),
 *   2. ada waktu baca minimal sejak checkpoint sebelumnya, dan
 *   3. berurutan (bagian 1, lalu 2, dst).
 * Checkpoint terakhir tercapai -> materi otomatis selesai. Server memeriksa ulang urutan dan waktunya.
 * Saat sebuah modul tuntas, ditampilkan alert SweetAlert (dengan cadangan alert biasa bila CDN tidak termuat).
 */
(function () {
    'use strict';

    var cfgEl = document.getElementById('learning-config');
    var cfg = {};
    try { cfg = cfgEl ? JSON.parse(cfgEl.textContent) : {}; } catch (e) { cfg = {}; }

    // ------------------------------------------------------------ util

    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    function $(id) { return document.getElementById(id); }

    // Notifikasi memakai sistem toast bersama (ui.js); aman bila ui.js tidak termuat.
    function toast(type, message, opts) { if (window.ewNotify) { window.ewNotify(type, message, opts); } }

    // ------------------------------------------------------------ alert

    function celebrate(m) {
        if (!m) { return; }

        var allDone = !!m.all_done;
        var hasNext = !allDone && m.next && m.next.url;
        var title = allDone ? 'Selamat! Semua modul selesai' : 'Selamat! Modul ' + m.number + ' selesai';

        var medal = m.badge_image
            ? '<img class="ew-swal-medal-img" alt="" src="' + esc(m.badge_image) + '">'
            : '<span class="ew-swal-medal-icon" aria-hidden="true">' + esc(m.badge_icon) + '</span>';

        var html = '<div class="ew-swal-medal">' + medal + '</div>'
            + '<p class="ew-swal-lead">Anda telah menyelesaikan <b>' + esc(m.title) + '</b>.</p>'
            + (m.badge ? '<p class="ew-swal-sub">Lencana \u201c' + esc(m.badge) + '\u201d kini masuk ke koleksi Anda.</p>' : '')
            + (allDone ? '<p class="ew-swal-sub">Sertifikat kelulusan sudah dapat dibuat di halaman Dashboard.</p>' : '');

        var confirmText = hasNext ? 'Lanjut ke Modul ' + m.next.number : (allDone ? 'Lihat Dashboard' : 'Ke Dashboard');
        var targetUrl = hasNext ? m.next.url : m.dashboard_url;

        if (window.Swal) {
            window.Swal.fire({
                title: title,
                html: html,
                showCancelButton: true,
                confirmButtonText: confirmText,
                cancelButtonText: 'Tutup',
                reverseButtons: true,
                allowOutsideClick: false,
                buttonsStyling: false,
                customClass: {
                    popup: 'ew-swal-popup',
                    title: 'ew-swal-title',
                    htmlContainer: 'ew-swal-html',
                    confirmButton: 'ew-swal-confirm',
                    cancelButton: 'ew-swal-cancel'
                }
            }).then(function (result) {
                if (result.isConfirmed && targetUrl) { window.location.href = targetUrl; }
            });
            return;
        }

        // Cadangan bila SweetAlert gagal dimuat (mis. tanpa internet).
        var message = title + '\n\nAnda telah menyelesaikan ' + m.title + '.\n\n' + confirmText + '?';
        if (window.confirm(message) && targetUrl) { window.location.href = targetUrl; }
    }

    function notifyLocked(message) {
        message = message || 'Selesaikan materi sebelumnya terlebih dahulu, ya.';
        if (window.Swal) {
            window.Swal.fire({
                icon: 'info',
                title: 'Belum bisa dibuka',
                text: message,
                confirmButtonText: 'Mengerti',
                buttonsStyling: false,
                customClass: { popup: 'ew-swal-popup', title: 'ew-swal-title', htmlContainer: 'ew-swal-html', confirmButton: 'ew-swal-confirm' }
            });
        } else {
            window.alert(message);
        }
    }

    // Tautan terkunci (menu & tombol "berikutnya") tidak berpindah halaman; beri penjelasan ramah.
    document.addEventListener('click', function (e) {
        var link = e.target.closest ? e.target.closest('a[aria-disabled="true"]') : null;
        if (!link) { return; }
        e.preventDefault();
        notifyLocked(link.getAttribute('data-locked-msg'));
    });

    // Alert selesai-modul yang dikirim server setelah lulus kuis / materi otomatis selesai.
    if (cfg.celebrate) { celebrate(cfg.celebrate); }

    // Halaman tanpa materi (modul kosong): tidak ada yang dilacak.
    if (!cfg.checkpointUrl) { return; }

    // ------------------------------------------------------------ state

    var total = parseInt(cfg.total, 10) || 0;
    var reached = parseInt(cfg.reached, 10) || 0;
    var completed = !!cfg.completed;
    var hasQuiz = !!cfg.hasQuiz;
    var mode = cfg.mode === 'pdf' ? 'pdf' : 'text';
    var dwell = cfg.dwell || [];

    var markers = [].slice.call(document.querySelectorAll('.ew-checkpoint[data-checkpoint]'));
    var pdfFrame = $('pdf-frame');

    var el = {
        bar: $('readbar'), label: $('reading-label'), count: $('reading-count'), track: $('reading-track'),
        fill: $('reading-fill'), hint: $('reading-hint'), chip: $('done-chip'),
        next: $('next-btn'), nextHint: $('next-hint'),
        quizLock: $('quiz-lock'), quizSet: $('quiz-fieldset')
    };

    var seen = {};            // checkpoint ke-n sudah sempat tampil di layar
    var pdfVisible = (mode !== 'pdf');
    var sectionSeconds = 0;   // detik aktif membaca bagian saat ini
    var busy = false;
    var netWarned = false;
    var stopped = false;
    var timer = null;

    function readingFinished() { return completed || reached >= total; }
    function trackingNeeded() { return !completed && total > 0 && reached < total; }

    // ------------------------------------------------------------ tampilan

    function markDone(upTo) {
        markers.forEach(function (m) {
            if (parseInt(m.getAttribute('data-checkpoint'), 10) <= upTo) { m.classList.add('is-done'); }
        });
    }

    function renderBar() {
        if (!el.fill) { return; }
        var pct = total ? Math.round((reached / total) * 100) : 100;
        el.fill.style.width = pct + '%';
        if (el.count) { el.count.textContent = reached + '/' + total; }
        if (el.track) { el.track.setAttribute('aria-valuenow', String(reached)); }
        if (el.label) {
            el.label.textContent = reached >= total ? 'Materi sudah dibaca sampai akhir' : 'Bagian ' + (reached + 1) + ' dari ' + total;
        }
        if (el.bar) { el.bar.classList.toggle('is-complete', reached >= total); }
    }

    function setHint(text) { if (el.hint && el.hint.textContent !== text) { el.hint.textContent = text; } }

    function updateHint() {
        if (completed) { setHint('Materi selesai. Anda dapat melanjutkan ke materi berikutnya.'); return; }
        if (reached >= total) {
            setHint(hasQuiz ? 'Materi sudah dibaca. Silakan kerjakan latihan di bawah untuk menyelesaikan materi ini.' : 'Materi selesai.');
            return;
        }
        var next = reached + 1;
        var need = parseInt(dwell[next - 1], 10) || 0;
        var visibleOk = mode === 'pdf' ? pdfVisible : !!seen[next];

        if (visibleOk && sectionSeconds < need) {
            setHint('Bagian ' + next + ' dari ' + total + ': tetap baca sebentar lagi (' + (need - sectionSeconds) + ' detik).');
        } else if (visibleOk) {
            setHint('Menyimpan progres\u2026');
        } else if (mode === 'pdf') {
            setHint('Gulir sampai dokumen PDF terlihat, lalu baca. Progres bertambah otomatis seiring waktu membaca.');
        } else {
            setHint('Gulir ke bawah dan baca setiap bagian. Progres bertambah otomatis.');
        }
    }

    function enableNext() {
        if (el.next) {
            el.next.classList.remove('is-disabled');
            el.next.removeAttribute('aria-disabled');
            el.next.removeAttribute('tabindex');
        }
        if (el.nextHint) { el.nextHint.hidden = true; }
    }

    function unlockQuiz() {
        if (el.quizSet) { el.quizSet.disabled = false; el.quizSet.classList.remove('is-locked'); }
        if (el.quizLock) { el.quizLock.hidden = true; }
    }

    function unlockLink(link) {
        if (!link) { return; }
        link.classList.remove('is-locked');
        link.removeAttribute('aria-disabled');
        link.removeAttribute('tabindex');
        link.removeAttribute('title');
    }

    function setRing(moduleId, percent) {
        var ring = $('module-ring-' + moduleId);
        if (!ring) { return; }
        ring.style.background = 'conic-gradient(var(--color-blue) ' + percent + '%, var(--color-blue-tint) 0)';
        var label = ring.querySelector('.ew-ring-label');
        if (label) { label.textContent = percent + '%'; }
    }

    function updateSidebar(d) {
        if (d.overall) {
            var count = $('overall-count'), bar = $('overall-bar');
            if (count) { count.textContent = d.overall.done; }
            if (bar) { bar.style.width = d.overall.percent + '%'; }
        }
        if (cfg.moduleId && typeof d.module_percent === 'number') { setRing(cfg.moduleId, d.module_percent); }

        if (d.completed) {
            var current = $('nav-lesson-' + cfg.lessonId);
            if (current) { current.classList.add('is-done'); }
        }
        if (d.unlocked) {
            unlockLink($('nav-lesson-' + d.unlocked.lesson_id));
            var moduleLink = document.querySelector('.ew-module[data-module-id="' + d.unlocked.module_id + '"]');
            if (moduleLink && moduleLink.classList.contains('is-locked')) {
                unlockLink(moduleLink);
                setRing(d.unlocked.module_id, 0);
            }
        }
    }

    function onCompleted(d) {
        completed = true;
        if (el.chip) { el.chip.hidden = false; }
        enableNext();
        if (d.module_completed) {
            window.setTimeout(function () { celebrate(d.module_completed); }, 500);
        } else {
            toast('success', 'Materi ini sudah selesai. Anda dapat melanjutkan ke materi berikutnya.', { title: 'Materi Selesai' });
        }
    }

    // ------------------------------------------------------------ kirim checkpoint

    function submit(next) {
        busy = true;
        if (el.bar) { el.bar.classList.add('is-saving'); }
        var need = parseInt(dwell[next - 1], 10) || 0;

        fetch(cfg.checkpointUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': cfg.csrf
            },
            body: JSON.stringify({ checkpoint: next })
        })
        .then(function (res) {
            return res.json().catch(function () { return {}; }).then(function (data) { return { status: res.status, data: data }; });
        })
        .then(function (r) {
            busy = false;
            netWarned = false;
            if (el.bar) { el.bar.classList.remove('is-saving'); }
            var d = r.data || {};

            if (r.status === 200 && d.ok) {
                reached = d.checkpoint;
                sectionSeconds = 0;
                markDone(reached);
                renderBar();
                updateSidebar(d);
                if (d.completed) { onCompleted(d); }
                else if (d.reading_done && hasQuiz) {
                    unlockQuiz();
                    toast('info', 'Materi sudah dibaca sampai akhir. Silakan kerjakan latihan di bawah.', { title: 'Latihan terbuka' });
                }
                updateHint();
                return;
            }

            if (r.status === 422) {
                // Server minta menunggu sedikit lebih lama / menyelaraskan urutan.
                if (typeof d.checkpoint === 'number') { reached = d.checkpoint; markDone(reached); renderBar(); }
                var wait = (parseInt(d.wait, 10) || 3) + 1;
                sectionSeconds = Math.max(0, need - wait);
                updateHint();
                return;
            }

            // 403 (terkunci), 419 (sesi habis), dll.: hentikan pelacakan dan beri tahu.
            stopped = true;
            window.clearInterval(timer);
            var failMsg = r.status === 419
                ? 'Sesi Anda sudah berakhir. Muat ulang halaman ini lalu masuk kembali bila diminta.'
                : (r.status === 403
                    ? 'Materi ini masih terkunci. Selesaikan materi sebelumnya terlebih dahulu.'
                    : 'Progres belum dapat disimpan. Muat ulang halaman ini lalu coba lagi.');
            setHint(failMsg);
            toast('error', failMsg, { title: 'Progres tidak tersimpan' });
        })
        .catch(function () {
            // Gangguan jaringan: coba lagi beberapa detik kemudian.
            busy = false;
            if (el.bar) { el.bar.classList.remove('is-saving'); }
            if (!netWarned) {
                netWarned = true;
                toast('warning', 'Koneksi internet terganggu. Progres membaca akan dicoba disimpan lagi otomatis.', { title: 'Koneksi terganggu' });
            }
            sectionSeconds = Math.max(0, need - 5);
            setHint('Koneksi terganggu. Mencoba menyimpan progres lagi\u2026');
        });
    }

    function evaluate() {
        if (stopped || busy || !trackingNeeded()) { updateHint(); return; }

        var next = reached + 1;
        var need = parseInt(dwell[next - 1], 10) || 0;
        var visibleOk = mode === 'pdf' ? pdfVisible : !!seen[next];

        if (visibleOk && sectionSeconds >= need) { submit(next); }
        updateHint();
    }

    // Cadangan untuk peramban lama tanpa IntersectionObserver.
    function fallbackSeen() {
        markers.forEach(function (m) {
            var n = parseInt(m.getAttribute('data-checkpoint'), 10);
            if (m.getBoundingClientRect().top < window.innerHeight * 0.92) { seen[n] = true; }
        });
    }

    function everySecond() {
        if (stopped || !trackingNeeded()) { window.clearInterval(timer); return; }
        if (document.visibilityState === 'visible' && (mode !== 'pdf' || pdfVisible)) { sectionSeconds += 1; }
        if (mode === 'text' && !('IntersectionObserver' in window)) { fallbackSeen(); }
        evaluate();
    }

    // ------------------------------------------------------------ mulai

    markDone(reached);
    renderBar();
    updateHint();

    if (!trackingNeeded()) { return; }

    if ('IntersectionObserver' in window) {
        if (mode === 'text') {
            var io = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) { seen[parseInt(entry.target.getAttribute('data-checkpoint'), 10)] = true; }
                });
                evaluate();
            }, { threshold: 0, rootMargin: '0px 0px -10% 0px' });
            markers.forEach(function (m) { io.observe(m); });
        } else if (pdfFrame) {
            new IntersectionObserver(function (entries) {
                pdfVisible = entries[0].isIntersecting;
                evaluate();
            }, { threshold: 0.4 }).observe(pdfFrame);
        } else {
            pdfVisible = true;
        }
    } else if (mode === 'pdf') {
        pdfVisible = true;
    }

    timer = window.setInterval(everySecond, 1000);
})();
