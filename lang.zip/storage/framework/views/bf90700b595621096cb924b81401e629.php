<?php $__env->startSection('content'); ?>
    <div class="min-h-[calc(100vh-84px)] grid place-items-center px-5 py-12">
        <div class="card w-full max-w-lg p-9 md:p-11">
            <div class="eyebrow">Verifikasi Email</div>
            <h1 class="text-3xl mt-2 mb-2">Satu langkah lagi</h1>
            <p class="text-ink text-lg">
                Kami sudah mengirim email berisi tautan verifikasi ke
                <b class="text-navy break-all"><?php echo e($email); ?></b>.
                Buka email tersebut, lalu tekan tombol <b>Verifikasi Email Saya</b>.
            </p>
            <p class="text-muted text-base">
                Tidak menemukannya? Periksa juga folder <b>Spam</b> atau <b>Promosi</b>. Tautan berlaku <?php echo e($menit); ?> menit.
            </p>

            <?php if(session('status') === 'verification-link-sent'): ?>
                <div class="mt-6 bg-green-tint text-green border-2 border-green/30 rounded-xl px-5 py-4 font-semibold text-base" role="status">
                    Tautan verifikasi baru sudah dikirim. Silakan periksa email Anda.
                </div>
            <?php endif; ?>
            <?php if(session('mail_error')): ?>
                <div class="mt-6 text-red text-base font-semibold" role="alert"><?php echo e(session('mail_error')); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('verification.send')); ?>" class="mt-7">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary w-full">Kirim Ulang Email Verifikasi</button>
            </form>

            <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-4 text-center">
                <?php echo csrf_field(); ?>
                <button class="border-0 bg-transparent text-blue-dark font-bold text-lg underline cursor-pointer">Keluar dan gunakan email lain</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>