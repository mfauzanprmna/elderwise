<?php $__env->startSection('content'); ?>
    <?php $isSelf = $user->exists && $user->id === auth()->id(); ?>
    <div class="max-w-2xl mx-auto px-5 md:px-10 py-10 md:py-14">
        <div class="eyebrow">Admin · <?php echo e($user->exists ? 'Edit Pengguna' : 'Pengguna Baru'); ?></div>
        <h1 class="text-3xl md:text-4xl mt-2 mb-1"><?php echo e($user->exists ? 'Edit pengguna' : 'Tambah pengguna'); ?></h1>
        <p class="text-muted text-lg mb-7">
            <?php echo e($user->exists ? 'Ubah data akun. Kolom kata sandi boleh dikosongkan jika tidak ingin mengubahnya.' : 'Buat akun baru untuk peserta atau admin.'); ?>

        </p>

        <?php if($user->exists): ?>
            <div class="card p-5 mb-6 grid sm:grid-cols-3 gap-4">
                <div><span class="text-muted text-sm font-bold">Progres belajar</span><strong class="block text-xl text-navy"><?php echo e($user->done_count); ?>/<?php echo e($totalLessons); ?> materi</strong></div>
                <div><span class="text-muted text-sm font-bold">Total XP</span><strong class="block text-xl text-navy"><?php echo e((int) $user->xp_total); ?></strong></div>
                <div><span class="text-muted text-sm font-bold">Sertifikat</span><strong class="block text-xl <?php echo e($user->certificate ? 'text-green' : 'text-muted'); ?>"><?php echo e($user->certificate ? '✓ ' . $user->certificate->displayNumber($certSetting) : 'Belum terbit'); ?></strong></div>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-tint text-red rounded-xl px-5 py-4 mb-6">
                <strong>Periksa kembali:</strong>
                <ul class="mt-2 ml-5 list-disc">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" id="user-form" autocomplete="off"
              action="<?php echo e($user->exists ? route('admin.users.update', $user) : route('admin.users.store')); ?>" class="grid gap-5">
            <?php echo csrf_field(); ?>
            <?php if($user->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <label class="form-label">Nama lengkap
                <input class="form-input" name="name" value="<?php echo e(old('name', $user->name)); ?>" required maxlength="120">
            </label>

            <label class="form-label">Email
                <input class="form-input" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required maxlength="190">
            </label>

            <div class="grid gap-2">
                <label class="form-label" for="role">Peran</label>
                <?php if($isSelf): ?>
                    <input type="hidden" name="role" value="admin">
                    <select id="role" class="form-input bg-bg cursor-not-allowed" disabled>
                        <option>Admin</option>
                    </select>
                    <small class="text-muted">Ini akun Anda sendiri, jadi perannya tidak bisa diturunkan.</small>
                <?php else: ?>
                    <select id="role" name="role" class="form-input" required>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if(old('role', $user->role) === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="text-muted">Peserta hanya mengakses materi belajar. Admin juga bisa mengelola modul, materi, sertifikat, dan pengguna.</small>
                <?php endif; ?>
            </div>

            <label class="form-label"><?php echo e($user->exists ? 'Kata sandi baru (opsional)' : 'Kata sandi'); ?>

                <input class="form-input pw-field" type="password" name="password" minlength="8" autocomplete="new-password" <?php if(! $user->exists): echo 'required'; endif; ?>>
                <small class="text-muted font-normal">Minimal 8 karakter.</small>
            </label>
            <label class="form-label">Ulangi kata sandi
                <input class="form-input pw-field" type="password" name="password_confirmation" minlength="8" autocomplete="new-password" <?php if(! $user->exists): echo 'required'; endif; ?>>
            </label>
            <label class="flex items-center gap-2.5 font-semibold text-lg cursor-pointer">
                <input type="checkbox" id="show-password" class="w-5.5 h-5.5"> Tampilkan kata sandi
            </label>

            <div class="flex justify-end gap-3 mt-2">
                <a class="btn btn-ghost" href="<?php echo e(route('admin.users.index')); ?>">Batal</a>
                <button class="btn btn-primary"><?php echo e($user->exists ? 'Simpan Perubahan' : 'Buat Akun'); ?></button>
            </div>
        </form>
    </div>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('show-password').addEventListener('change', function () {
    document.querySelectorAll('.pw-field').forEach(function (el) { el.type = this.checked ? 'text' : 'password'; }, this);
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views\admin\users\form.blade.php ENDPATH**/ ?>