<?php
namespace App\Http\Controllers;

use App\Models\Lesson;
use App\Models\LessonProgress;
use App\Support\LearningPath;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProgressController extends Controller
{
    /**
     * Browser melaporkan satu checkpoint (bagian) materi sudah dilewati.
     *
     * Aturan di server:
     *  - materi harus sudah terbuka (urutan belajar),
     *  - checkpoint harus berurutan (tidak boleh melompat),
     *  - sejak halaman dibuka / checkpoint sebelumnya harus ada waktu baca minimal.
     * Checkpoint terakhir tercapai -> materi otomatis selesai (kecuali ada kuis: selesai setelah lulus kuis).
     */
    public function checkpoint(Request $request, Lesson $lesson): JsonResponse
    {
        $user = Auth::user();
        $path = new LearningPath($user);

        if (! $path->isUnlocked($lesson)) {
            return response()->json(['ok' => false, 'message' => 'Materi ini masih terkunci.'], 403);
        }

        $data = $request->validate(['checkpoint' => ['required', 'integer', 'min:1']]);

        $sections = $lesson->readingPlan()['sections'];
        $total = count($sections);

        $progress = LessonProgress::firstOrCreate(
            ['user_id' => $user->id, 'lesson_id' => $lesson->id],
            ['checkpoint' => 0]
        );

        if ($progress->completed_at) {
            return response()->json($this->state($lesson, $progress, $total, $path, false));
        }

        $next = (int) $progress->checkpoint + 1;

        if ((int) $data['checkpoint'] !== $next || $next > $total) {
            return response()->json(array_merge(
                $this->state($lesson, $progress, $total, $path, false),
                ['ok' => false, 'message' => 'Urutan bagian tidak sesuai. Silakan lanjutkan membaca dari bagian berikutnya.']
            ), 422);
        }

        // Waktu baca minimal (60% dari yang diminta browser, supaya selisih jam/pengaturan waktu tidak mengganggu).
        $required = (int) floor(((int) $sections[$next - 1]['dwell']) * 0.6);
        $since = $progress->checkpoint_at ?? $progress->created_at;
        $elapsed = now()->timestamp - $since->timestamp;

        if ($elapsed < $required) {
            return response()->json(array_merge(
                $this->state($lesson, $progress, $total, $path, false),
                ['ok' => false, 'wait' => max(1, $required - $elapsed), 'message' => 'Mohon baca bagian ini sedikit lebih lama.']
            ), 422);
        }

        $progress->checkpoint = $next;
        $progress->checkpoint_at = now();

        $justCompleted = false;
        if ($next >= $total && ! $lesson->hasQuiz()) {
            $progress->completed_at = now();
            $progress->xp = 1;
            $justCompleted = true;
        }
        $progress->save();

        return response()->json($this->state($lesson, $progress, $total, new LearningPath($user), $justCompleted));
    }

    public function quiz(Request $request, Lesson $lesson): RedirectResponse
    {
        $user = Auth::user();
        $path = new LearningPath($user);
        abort_unless($path->isUnlocked($lesson), 403);

        $quiz = is_array($lesson->quiz) ? $lesson->quiz : [];
        if (count($quiz) === 0) {
            return back();
        }

        $progress = LessonProgress::firstOrCreate(
            ['user_id' => $user->id, 'lesson_id' => $lesson->id],
            ['checkpoint' => 0]
        );

        // Latihan baru boleh dikerjakan setelah materinya dibaca sampai bagian akhir.
        $readingDone = $progress->completed_at || (int) $progress->checkpoint >= $lesson->checkpointTotal();
        if (! $readingDone) {
            return back()->with('quiz_locked', 'Baca materi sampai bagian akhir terlebih dahulu, baru latihan ini bisa dikerjakan.');
        }

        $answers = $request->input('answers', []);
        $answers = is_array($answers) ? $answers : [];
        $score = 0;
        foreach ($quiz as $i => $q) {
            if (isset($answers[$i]) && (string) $answers[$i] === (string) ($q['answer'] ?? '')) {
                $score++;
            }
        }
        $passed = $score === count($quiz);

        if ($passed && ! $progress->completed_at) {
            $progress->completed_at = now();
            $progress->xp = 3;
            $progress->save();

            $path = new LearningPath($user);
            $module = $path->moduleOf($lesson);
            if ($module && $path->isModuleComplete($module)) {
                session()->flash('module_completed', $path->moduleCompletionPayload($module));
            }
        }

        return back()->with('quiz_result', ['score' => $score, 'total' => count($quiz), 'passed' => $passed]);
    }

    /** Status progres materi untuk dikirim ke browser. */
    private function state(Lesson $lesson, LessonProgress $progress, int $total, LearningPath $path, bool $justCompleted): array
    {
        $completed = (bool) $progress->completed_at;
        $reached = $completed ? $total : min((int) $progress->checkpoint, $total);
        $module = $path->moduleOf($lesson);

        $state = [
            'ok' => true,
            'checkpoint' => $reached,
            'total' => $total,
            'reading_done' => $completed || $reached >= $total,
            'completed' => $completed,
            'just_completed' => $justCompleted,
            'module_completed' => null,
            'module_percent' => $module ? $path->modulePercent($module) : null,
            'overall' => [
                'done' => $path->completedCount(),
                'total' => $path->totalCount(),
                'percent' => $path->overallPercent(),
            ],
            'unlocked' => null,
        ];

        if ($justCompleted) {
            if ($module && $path->isModuleComplete($module)) {
                $state['module_completed'] = $path->moduleCompletionPayload($module);
            }
            $next = $path->next($lesson);
            if ($next) {
                $state['unlocked'] = [
                    'lesson_id' => $next->id,
                    'module_id' => $next->module_id,
                    'url' => route('learning.show', [$next->module_id, $next->id]),
                ];
            }
        }

        return $state;
    }
}
