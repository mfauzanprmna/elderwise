<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['module', 'state' => 'locked', 'size' => 56]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['module', 'state' => 'locked', 'size' => 56]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    // state: done = medali berwarna penuh, progress = sedang dikerjakan, locked = belum terbuka
    $c = $module->badgeColor();
    $style = match ($state) {
        'done' => "background:linear-gradient(135deg,{$c['from']},{$c['to']});border-color:{$c['border']};",
        'progress' => 'background:var(--color-blue-tint);border-color:var(--color-blue);',
        default => 'background:var(--color-bg);border-color:var(--color-line);',
    };
    $img = $module->badgeImageUrl();
?>
<div <?php echo e($attributes->merge(['class' => 'rounded-full grid place-items-center shrink-0 border-2 overflow-hidden ' . ($state === 'locked' ? 'grayscale opacity-45' : '') . ($state === 'done' ? ' shadow-elder' : '')])); ?>

     style="width:<?php echo e($size); ?>px;height:<?php echo e($size); ?>px;font-size:<?php echo e(round($size * 0.45)); ?>px;<?php echo e($style); ?>">
    <?php if($img): ?>
        <img src="<?php echo e($img); ?>" alt="" class="w-[68%] h-[68%] object-contain">
    <?php else: ?>
        <span aria-hidden="true"><?php echo e($module->badgeIcon()); ?></span>
    <?php endif; ?>
</div>
<?php /**PATH D:\Project\elderwise-laravel12\resources\views\components\badge-medal.blade.php ENDPATH**/ ?>