<?php $__env->startSection('hide_footer', '1'); ?>

<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/learning.css')); ?>?v=<?php echo e(@filemtime(public_path('css/learning.css'))); ?>">
<?php $__env->stopPush(); ?>

<?php
    $celebrate = session('module_completed') ?? $moduleCompleted;
    $overallPct = $path->overallPercent();

    $nextLabel = ($nextModule && $nextModule->id !== $module->id)
        ? 'Lanjut ke Modul ' . $nextModule->number
        : 'Materi Berikutnya';

    // Status kemajuan materi ini: 0% sampai materi digulir habis (atau latihan lulus), lalu langsung 100%.
    $statusState = $completedThis ? 'done' : ($lesson && $lesson->hasQuiz() && $readingDone && $lesson->hasReadableContent() ? 'quiz' : 'todo');
    $statusText = ['done' => '100% · Materi selesai', 'quiz' => 'Tinggal mengerjakan latihan', 'todo' => '0% · Belum selesai'][$statusState];

    $config = [
        'celebrate' => $celebrate,
        'lessonId' => $lesson?->id,
        'moduleId' => $module->id,
        'finishUrl' => $lesson ? route('learning.finish', $lesson) : null,
        'csrf' => csrf_token(),
        'needsReading' => $needsReading,
        'completed' => $completedThis,
        'hasQuiz' => $lesson ? $lesson->hasQuiz() : false,
    ];
?>

<?php $__env->startSection('content'); ?>
    <div id="learn-grid" class="ew-learn grid grid-cols-1 md:grid-cols-[360px_1fr] h-[calc(100vh-84px)] md:h-[calc(100vh-84px)] overflow-hidden">
        
        <script>try { if (localStorage.getItem('ew-learn-menu') === 'closed') { document.getElementById('learn-grid').classList.add('is-collapsed'); } } catch (e) {}</script>

        
        <button type="button" id="learning-toggle" class="ew-side-toggle" aria-controls="learning-sidebar" aria-expanded="true"
                aria-label="Tutup menu belajar" title="Tutup menu belajar">
            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12.5 4.5l-5 5.5 5 5.5"/></svg>
        </button>

        
        <aside id="learning-sidebar" class="bg-white border-b-2 md:border-b-0 md:border-r-2 border-line overflow-auto max-h-[46vh] md:max-h-none">
            <div class="px-6 pt-6 pb-4 border-b-2 border-line">
                <div class="eyebrow"><?php echo e($site->site_name); ?></div>
                <h2 class="text-xl mt-1 mb-3">Peta Belajar</h2>
                <div class="text-navy text-sm font-semibold">
                    <span><span id="overall-count"><?php echo e($path->completedCount()); ?></span> dari <?php echo e($path->totalCount()); ?> materi selesai</span>
                    <div class="h-2 bg-blue-tint rounded-full mt-2 overflow-hidden">
                        <div id="overall-bar" class="ew-fill h-full bg-blue rounded-full" style="width:<?php echo e($overallPct); ?>%"></div>
                    </div>
                </div>
            </div>

            <div class="p-2.5">
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $modulePct = $path->modulePercent($m);
                        $moduleUnlocked = $path->isModuleUnlocked($m);
                        $isOpen = $module->id === $m->id;
                    ?>
                    <div class="p-1.5">
                        <a href="<?php echo e(route('learning.show', $m)); ?>" data-module-id="<?php echo e($m->id); ?>"
                           data-locked-msg="Modul ini masih terkunci. Selesaikan modul sebelumnya terlebih dahulu, ya."
                           <?php if (! ($moduleUnlocked)): ?> aria-disabled="true" tabindex="-1" <?php endif; ?>
                           class="ew-module flex items-center gap-3 px-3 py-3.5 rounded-xl no-underline text-base <?php echo e($moduleUnlocked ? '' : 'is-locked'); ?> <?php echo e($isOpen ? 'bg-blue-tint text-blue-dark font-extrabold' : 'text-navy'); ?>">
                            <span id="module-ring-<?php echo e($m->id); ?>" class="ew-ring relative w-[38px] h-[38px] rounded-full grid place-items-center shrink-0"
                                  style="background:conic-gradient(var(--color-blue) <?php echo e($modulePct); ?>%, var(--color-blue-tint) 0)">
                                <span class="absolute w-[28px] h-[28px] bg-white rounded-full"></span>
                                <span class="ew-ring-label relative text-[9px] font-extrabold text-blue-dark"><?php echo e($modulePct); ?>%</span>
                                <span class="ew-ring-lock"><?php if (isset($component)) { $__componentOriginal8b68130482bb7c68f7f792d0471059b0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b68130482bb7c68f7f792d0471059b0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-lock','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon-lock'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b68130482bb7c68f7f792d0471059b0)): ?>
<?php $attributes = $__attributesOriginal8b68130482bb7c68f7f792d0471059b0; ?>
<?php unset($__attributesOriginal8b68130482bb7c68f7f792d0471059b0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b68130482bb7c68f7f792d0471059b0)): ?>
<?php $component = $__componentOriginal8b68130482bb7c68f7f792d0471059b0; ?>
<?php unset($__componentOriginal8b68130482bb7c68f7f792d0471059b0); ?>
<?php endif; ?></span>
                            </span>
                            <span class="flex-1 min-w-0">
                                <b class="block">Modul <?php echo e($m->number); ?></b>
                                <span class="ew-module-title block text-sm font-normal truncate"><?php echo e($m->title); ?></span>
                            </span>
                        </a>

                        <?php if($isOpen): ?>
                            <div class="pl-3.5 pt-1.5 pb-2">
                                <?php $__currentLoopData = $m->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $isCurrent = $lesson?->id === $l->id;
                                        $isDone = $path->isCompleted($l);
                                        $lessonUnlocked = $path->isUnlocked($l);
                                    ?>
                                    <a href="<?php echo e(route('learning.show', [$m, $l])); ?>" id="nav-lesson-<?php echo e($l->id); ?>"
                                       data-locked-msg="Materi ini masih terkunci. Selesaikan materi sebelumnya terlebih dahulu, ya."
                                       <?php if (! ($lessonUnlocked)): ?> aria-disabled="true" tabindex="-1" title="Terkunci: selesaikan materi sebelumnya dulu" <?php endif; ?>
                                       <?php if($isCurrent): ?> aria-current="page" <?php endif; ?>
                                       class="ew-lesson flex items-center gap-3 no-underline px-2.5 py-3 rounded-xl text-base leading-snug <?php echo e($isDone ? 'is-done' : ''); ?> <?php echo e($lessonUnlocked ? '' : 'is-locked'); ?>

                                              <?php echo e($isCurrent ? 'bg-blue-tint text-blue-dark font-bold shadow-[inset_3px_0_0_var(--color-blue)]' : 'text-ink'); ?>">
                                        <span class="ew-badge min-w-[34px] h-[34px] rounded-full grid place-items-center text-[11px] font-extrabold shrink-0 bg-blue-tint/60 text-navy">
                                            <span class="ew-badge-code"><?php echo e($l->code); ?></span>
                                            <span class="ew-badge-check">✓</span>
                                            <span class="ew-badge-lock"><?php if (isset($component)) { $__componentOriginal8b68130482bb7c68f7f792d0471059b0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b68130482bb7c68f7f792d0471059b0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-lock','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon-lock'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b68130482bb7c68f7f792d0471059b0)): ?>
<?php $attributes = $__attributesOriginal8b68130482bb7c68f7f792d0471059b0; ?>
<?php unset($__attributesOriginal8b68130482bb7c68f7f792d0471059b0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b68130482bb7c68f7f792d0471059b0)): ?>
<?php $component = $__componentOriginal8b68130482bb7c68f7f792d0471059b0; ?>
<?php unset($__componentOriginal8b68130482bb7c68f7f792d0471059b0); ?>
<?php endif; ?></span>
                                        </span>
                                        <span><?php echo e($l->title); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </aside>

        
        <section class="overflow-auto bg-bg px-5 md:px-[5vw] pt-9 pb-16" id="lesson-scroller">
            <div class="flex flex-wrap justify-between gap-2.5 text-navy text-base font-semibold">
                <a href="<?php echo e(route('dashboard')); ?>" class="text-blue-dark no-underline font-bold hover:underline">← Dashboard</a>
                <span>Modul <?php echo e($module->number); ?> · <?php echo e($module->title); ?></span>
            </div>

            <?php if($lesson): ?>
                <div class="max-w-3xl mx-auto mt-8 mb-6">
                    <div class="eyebrow"><?php echo e($lesson->code); ?></div>
                    <h1 class="text-3xl md:text-4xl mt-2 mb-2"><?php echo e($lesson->title); ?></h1>
                    <p class="text-ink text-lg"><?php echo e($module->slogan); ?></p>
                    <p class="mt-3 mb-0">
                        <span id="lesson-status" class="ew-status" data-state="<?php echo e($statusState); ?>" role="status"><?php echo e($statusText); ?></span>
                    </p>
                </div>

                <div class="max-w-4xl mx-auto card overflow-hidden">
                    <?php if($lesson->isPdf()): ?>
                        <iframe id="pdf-frame" title="Dokumen PDF: <?php echo e($lesson->title); ?>" class="block w-full h-[70vh] border-0" src="<?php echo e(Storage::url($lesson->pdf_path)); ?>"></iframe>
                    <?php else: ?>
                        <div id="lesson-content" class="lesson-prose p-8 md:p-10 text-lg leading-[1.75] max-w-none"><?php echo $lesson->renderedContent(); ?></div>
                    <?php endif; ?>

                    
                    <div id="content-end" class="ew-endmark" aria-hidden="true"></div>

                    <?php if($lesson->hasQuiz()): ?>
                        <div id="quiz-box" class="m-6 md:m-8 mt-0 bg-blue-50 border-2 border-line rounded-2xl p-7" style="background:#f2f7fc">
                            <div class="eyebrow">Uji Pemahaman</div>
                            <h2 class="text-2xl mt-1 mb-5">Sudah bisa?</h2>

                            <p id="quiz-lock" class="ew-quiz-lock" <?php if($readingDone): ?> hidden <?php endif; ?>>
                                <?php if (isset($component)) { $__componentOriginal8b68130482bb7c68f7f792d0471059b0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b68130482bb7c68f7f792d0471059b0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-lock','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon-lock'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b68130482bb7c68f7f792d0471059b0)): ?>
<?php $attributes = $__attributesOriginal8b68130482bb7c68f7f792d0471059b0; ?>
<?php unset($__attributesOriginal8b68130482bb7c68f7f792d0471059b0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b68130482bb7c68f7f792d0471059b0)): ?>
<?php $component = $__componentOriginal8b68130482bb7c68f7f792d0471059b0; ?>
<?php unset($__componentOriginal8b68130482bb7c68f7f792d0471059b0); ?>
<?php endif; ?> Gulir materi sampai akhir terlebih dahulu, baru latihan ini terbuka.
                            </p>

                            <form method="POST" action="<?php echo e(route('learning.quiz', $lesson)); ?>">
                                <?php echo csrf_field(); ?>
                                <fieldset id="quiz-fieldset" class="ew-fieldset <?php echo e($readingDone ? '' : 'is-locked'); ?>" <?php if(! $readingDone): echo 'disabled'; endif; ?>>
                                    <?php $__currentLoopData = $lesson->quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="my-6">
                                            <h3 class="text-lg text-navy font-bold mb-2"><?php echo e($i + 1); ?>. <?php echo e($q['question']); ?></h3>
                                            <?php $__currentLoopData = $q['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oi => $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="flex items-center gap-3 bg-white px-4 py-3.5 border-2 border-line rounded-xl my-2.5 font-semibold text-base cursor-pointer hover:border-blue">
                                                    <input type="radio" name="answers[<?php echo e($i); ?>]" value="<?php echo e($oi); ?>" required class="w-5.5 h-5.5 shrink-0">
                                                    <span><?php echo e($opt); ?></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button class="btn btn-primary mt-2" data-loading-text="Memeriksa jawaban…">Periksa Jawaban</button>
                                </fieldset>
                            </form>

                            <?php if(session('quiz_result')): ?>
                                <?php $passed = session('quiz_result.passed'); ?>
                                <div class="mt-5 px-5 py-4 rounded-xl text-lg font-semibold <?php echo e($passed ? 'bg-green-tint text-green' : 'bg-amber-tint text-amber'); ?>">
                                    Skor Anda: <b><?php echo e(session('quiz_result.score')); ?>/<?php echo e(session('quiz_result.total')); ?></b>.
                                    <?php echo e($passed ? 'Materi ini tercatat selesai!' : 'Coba lagi pelan-pelan.'); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="max-w-4xl mx-auto mt-6">
                    <div class="ew-lessonnav-row">
                        <div>
                            <?php if($prevLesson): ?>
                                <a class="btn btn-ghost" href="<?php echo e(route('learning.show', [$prevLesson->module_id, $prevLesson->id])); ?>">← Materi Sebelumnya</a>
                            <?php endif; ?>
                        </div>

                        <div class="text-center">
                            <div id="done-chip" class="inline-block px-5 py-3.5 rounded-xl bg-green-tint text-green font-extrabold text-lg" <?php if (! ($completedThis)): ?> hidden <?php endif; ?>>✓ Materi Selesai</div>
                        </div>

                        <div class="text-right">
                            <?php if($nextLesson): ?>
                                <a id="next-btn" class="btn btn-primary <?php echo e($nextUnlocked ? '' : 'is-disabled'); ?>"
                                   href="<?php echo e(route('learning.show', [$nextLesson->module_id, $nextLesson->id])); ?>"
                                   data-locked-msg="Selesaikan materi ini terlebih dahulu agar materi berikutnya terbuka."
                                   <?php if (! ($nextUnlocked)): ?> aria-disabled="true" tabindex="-1" <?php endif; ?>><?php echo e($nextLabel); ?> →</a>
                            <?php else: ?>
                                <a class="btn btn-primary" href="<?php echo e(route('dashboard')); ?>">Kembali ke Dashboard →</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if($nextLesson): ?>
                        <p id="next-hint" class="ew-next-hint" <?php if($nextUnlocked): ?> hidden <?php endif; ?>>Selesaikan materi ini untuk membuka materi berikutnya.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-24 px-5">
                    <h2 class="text-2xl">Belum ada materi pada modul ini.</h2>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="application/json" id="learning-config"><?php echo json_encode($config, 15, 512) ?></script>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.26.25/sweetalert2.all.min.js" defer></script>
        <script src="<?php echo e(asset('js/learning.js')); ?>?v=<?php echo e(@filemtime(public_path('js/learning.js'))); ?>" defer></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/learning/show.blade.php ENDPATH**/ ?>