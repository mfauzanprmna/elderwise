<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto px-5 md:px-10 py-10 md:py-14">

        <div class="flex flex-wrap justify-between items-end gap-6 mb-8">
            <div>
                <div class="eyebrow"><?php echo e($site->site_name); ?> · Admin</div>
                <h1 class="text-3xl md:text-4xl mt-2 mb-1">Pengaturan Sertifikat</h1>
                <p class="text-lg text-ink m-0">Unggah gambar latar sertifikat, lalu geser tiap tulisan ke posisi yang diinginkan.</p>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="bg-red-tint text-red rounded-xl px-5 py-4 mb-6">
                <b>Periksa kembali isian berikut:</b>
                <ul class="mt-2 ml-5 list-disc">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="mb-4">
            <h2 class="text-2xl mb-1">1. Gambar Latar Sertifikat</h2>
            <p class="text-ink m-0">Format JPG/PNG, ukuran landscape disarankan (misal 1600×1130 px).</p>
        </div>
        <div class="card p-6 mb-11">
            <form method="POST" action="<?php echo e(route('admin.certificate.background')); ?>" enctype="multipart/form-data" class="grid gap-4 max-w-lg">
                <?php echo csrf_field(); ?>
                <label class="form-label">
                    Pilih gambar latar baru
                    <input type="file" name="background" accept="image/png,image/jpeg" required class="form-input">
                </label>
                <?php $__errorArgs = ['background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red text-sm font-semibold"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="btn btn-primary">Unggah Gambar</button>
            </form>
            <?php if($setting->background_path): ?>
                <p class="mt-4 inline-block px-3.5 py-2.5 rounded-lg bg-green-tint text-green font-semibold">
                    ✓ Gambar latar aktif: <?php echo e(basename($setting->background_path)); ?> (<?php echo e($setting->background_width); ?>×<?php echo e($setting->background_height); ?>px)
                </p>
            <?php else: ?>
                <p class="text-muted mt-4">Belum ada gambar latar. Unggah dulu sebelum mengatur posisi tulisan.</p>
            <?php endif; ?>
        </div>

        <?php if($setting->background_path): ?>
            
            <div class="flex flex-wrap justify-between items-end gap-5 mb-4">
                <div>
                    <h2 class="text-2xl mb-1">2. Atur Posisi Tulisan</h2>
                    <p class="text-ink m-0">Geser setiap kotak ke tempat yang sesuai di atas gambar. Teks yang tampil adalah <b>contoh isi</b>, supaya Bapak/Ibu bisa melihat perkiraan hasil aslinya.</p>
                </div>
                <a href="<?php echo e(route('admin.certificate.preview')); ?>" target="_blank" class="btn btn-ghost">🔍 Lihat Pratinjau PDF</a>
            </div>

            <form method="POST" action="<?php echo e(route('admin.certificate.fields')); ?>" id="certificate-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="title" value="<?php echo e($setting->title); ?>">
                <div id="fields-data-holder"></div>

                <div class="cert-builder">
                    <div class="cert-canvas-wrap">
                        <div class="cert-canvas" id="cert-canvas" data-bg-width="<?php echo e($setting->background_width ?? 1600); ?>" data-bg-src="/storage/<?php echo e($setting->background_path); ?>" style="background-image:url('/storage/<?php echo e($setting->background_path); ?>')">
                            <div class="cert-canvas-error" id="cert-canvas-error" hidden>
                                ⚠️ Gambar latar gagal dimuat. Jalankan <code>php artisan storage:link</code> di server, lalu muat ulang halaman ini.
                            </div>
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $sampleText = match($f['source'] ?? null) {
                                        'user_name' => $sample['user_name'],
                                        'issued_date' => $sample['issued_date'],
                                        'certificate_number' => $sample['certificate_number'],
                                        default => $f['value'] ?: $f['label'],
                                    };
                                ?>
                                <div class="cert-token align-<?php echo e($f['align']); ?> <?php echo e(($f['visible'] ?? true) ? '' : 'is-hidden'); ?>"
                                     data-index="<?php echo e($i); ?>"
                                     data-key="<?php echo e($f['key']); ?>"
                                     data-source="<?php echo e($f['source'] ?? ''); ?>"
                                     data-fontsize="<?php echo e($f['font_size']); ?>"
                                     style="left:<?php echo e($f['x']); ?>%; top:<?php echo e($f['y']); ?>%; color:<?php echo e($f['color']); ?>; font-weight:<?php echo e(!empty($f['bold']) ? '700':'400'); ?>; text-align:<?php echo e($f['align']); ?>;">
                                    <span class="cert-token-label"><?php echo e($f['label']); ?></span>
                                    <span class="cert-token-sample"><?php echo e($sampleText); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <p class="text-muted text-sm mt-3">Seret kotak teks ke posisi yang diinginkan. Ukuran huruf di sini mengikuti skala asli, dan teks yang tampil adalah contoh isi supaya mudah dicek apakah pas atau kepotong. Klik "Lihat Pratinjau PDF" untuk melihat hasil sebenarnya.</p>
                        <p class="text-muted text-sm mt-2"><b>Halaman 2</b> sertifikat (rincian materi seperti rapor dan total JP) dibuat otomatis dari daftar modul, 1 modul = 1 JP. Tidak perlu diatur di sini, dan ikut muncul di pratinjau PDF.</p>
                    </div>

                    <div class="cert-panel">
                        <h3 class="text-xl mt-0 mb-4">Daftar Tulisan</h3>
                        <div id="cert-field-list">
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="cert-field-row" data-index="<?php echo e($i); ?>">
                                    <div class="flex justify-between items-center mb-2">
                                        <label class="flex items-center gap-2 cursor-pointer">
                                            <input type="checkbox" class="f-visible w-5 h-5" <?php echo e(($f['visible'] ?? true) ? 'checked':''); ?>>
                                            <b class="text-navy"><?php echo e($f['label']); ?></b>
                                        </label>
                                        <?php if(($f['kind'] ?? 'dynamic') === 'custom'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.certificate.fields.remove', $f['key'])); ?>" class="f-remove-form m-0" onsubmit="return confirm('Hapus tulisan ini dari sertifikat?')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="border-0 bg-transparent text-red font-bold text-sm cursor-pointer">Hapus</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="bg-blue-tint text-blue-dark text-xs font-extrabold rounded-full px-2.5 py-1">bawaan</span>
                                        <?php endif; ?>
                                    </div>

                                    <?php if(($f['kind'] ?? 'dynamic') === 'custom' || $f['source'] === 'program_name'): ?>
                                        <label class="cert-mini-label">Teks / isi
                                            <input type="text" class="f-value" value="<?php echo e($f['value']); ?>" maxlength="500">
                                        </label>
                                    <?php else: ?>
                                        <p class="text-sm text-muted mt-1.5 leading-relaxed">
                                            Isi otomatis: <?php echo e(match($f['source']) { 'user_name' => 'nama peserta yang login', 'issued_date' => 'tanggal sertifikat dibuat', 'certificate_number' => 'nomor sertifikat unik', default => '-' }); ?>

                                            <br>Contoh: <i><?php echo e(match($f['source']) { 'user_name' => $sample['user_name'], 'issued_date' => $sample['issued_date'], 'certificate_number' => $sample['certificate_number'], default => '-' }); ?></i>
                                        </p>
                                    <?php endif; ?>

                                    <div class="grid grid-cols-2 gap-3">
                                        <label class="cert-mini-label">Ukuran huruf
                                            <input type="number" class="f-fontsize" value="<?php echo e($f['font_size']); ?>" min="8" max="120">
                                        </label>
                                        <label class="cert-mini-label">Warna
                                            <input type="color" class="f-color" value="<?php echo e($f['color']); ?>">
                                        </label>
                                    </div>
                                    <label class="cert-mini-label">Perataan teks
                                        <select class="f-align">
                                            <option value="left" <?php echo e($f['align'] === 'left' ? 'selected' : ''); ?>>Kiri</option>
                                            <option value="center" <?php echo e($f['align'] === 'center' ? 'selected' : ''); ?>>Tengah</option>
                                            <option value="right" <?php echo e($f['align'] === 'right' ? 'selected' : ''); ?>>Kanan</option>
                                        </select>
                                    </label>
                                    <label class="flex items-center gap-2 mt-2 cursor-pointer">
                                        <input type="checkbox" class="f-bold w-5 h-5" <?php echo e(!empty($f['bold']) ? 'checked' : ''); ?>>
                                        <span class="text-sm font-semibold">Huruf tebal</span>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <button type="submit" class="btn btn-primary w-full mt-4">Simpan Pengaturan Sertifikat</button>
                    </div>
                </div>
            </form>

            
            <div class="mt-11 mb-4">
                <h2 class="text-2xl mb-1">3. Tambah Tulisan Baru</h2>
                <p class="text-ink m-0">Misalnya "Diselenggarakan oleh", "Durasi Pelatihan", atau nama penandatangan.</p>
            </div>
            <div class="card p-6">
                <form method="POST" action="<?php echo e(route('admin.certificate.fields.add')); ?>" class="grid sm:grid-cols-2 gap-4 items-end">
                    <?php echo csrf_field(); ?>
                    <label class="form-label">
                        Nama tulisan (label)
                        <input type="text" name="label" placeholder="Contoh: Diselenggarakan oleh" required maxlength="120" class="form-input">
                    </label>
                    <label class="form-label">
                        Isi teks
                        <input type="text" name="value" placeholder="Contoh: Politeknik Negeri Jakarta" maxlength="500" class="form-input">
                    </label>
                    <button class="btn btn-ghost sm:col-span-2">+ Tambah Tulisan</button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    
    <style>
        .cert-builder{display:grid;grid-template-columns:1fr 340px;gap:24px;align-items:start;margin-top:10px}
        .cert-canvas-wrap{position:sticky;top:24px}
        .cert-canvas{
            position:relative;width:100%;aspect-ratio:1600/1130;
            background-size:cover;background-position:center;
            border:2px solid var(--color-line);border-radius:1.125rem;overflow:hidden;
            box-shadow:var(--shadow-elder);
        }
        .cert-token{
            position:absolute;transform:translate(-50%,-50%);
            padding:5px 11px;border-radius:6px;
            background:rgba(255,255,255,.72);
            border:1.5px dashed var(--color-blue);
            cursor:grab;user-select:none;white-space:nowrap;
            line-height:1.25;display:flex;flex-direction:column;gap:1px;
        }
        .cert-token-label{
            font-size:10px;font-weight:800;letter-spacing:.03em;
            color:var(--color-blue-dark);text-transform:uppercase;
            background:#fff;padding:1px 5px;border-radius:4px;
            align-self:flex-start;
        }
        .cert-token.align-center .cert-token-label{align-self:center}
        .cert-token.align-right .cert-token-label{align-self:flex-end}
        .cert-token-sample{font-size:inherit;color:inherit;font-weight:inherit}
        .cert-token.align-left{transform:translateY(-50%)}
        .cert-token.align-right{transform:translate(-100%,-50%)}
        .cert-token.dragging{cursor:grabbing;background:rgba(255,255,255,.92);z-index:10}
        .cert-token.is-hidden{opacity:.3}
        .cert-token.selected{outline:3px solid var(--color-blue-dark)}
        .cert-canvas-error{
            position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
            text-align:center;padding:30px;background:#fff3f0;color:var(--color-red);
            font-weight:700;font-size:15px;line-height:1.6;z-index:5;
        }
        .cert-canvas-error code{background:#fff;padding:2px 6px;border-radius:4px;font-size:13px}
        .cert-panel{background:#fff;border:2px solid var(--color-line);border-radius:1.125rem;padding:20px;max-height:80vh;overflow:auto}
        .cert-field-row{border:2px solid var(--color-line);border-radius:0.75rem;padding:14px;margin-bottom:14px}
        .cert-field-row.active{border-color:var(--color-blue)}
        .cert-mini-label{display:grid;gap:5px;font-size:14px;font-weight:700;margin-top:8px}
        .cert-mini-label input,.cert-mini-label select{font:inherit;padding:8px 10px;border:2px solid var(--color-line-strong);border-radius:8px;font-size:14px;min-height:auto}
        @media(max-width:1000px){.cert-builder{grid-template-columns:1fr}.cert-canvas-wrap{position:static}}
    </style>

    <script>
    (function(){
        const canvas = document.getElementById('cert-canvas');
        if(!canvas) return;
        const form = document.getElementById('certificate-form');
        const holder = document.getElementById('fields-data-holder');
        const rows = Array.from(document.querySelectorAll('.cert-field-row'));
        const tokens = Array.from(document.querySelectorAll('.cert-token'));
        // Skala huruf mengikuti lebar halaman PDF (A4 landscape = 297 mm ≈ 1122,5 px @96dpi), bukan lebar gambar latar,
        // supaya ukuran huruf di kanvas sama proporsinya dengan hasil PDF.
        const bgWidth = 1122.5;

        const bgTest = new Image();
        bgTest.onerror = () => {
            const err = document.getElementById('cert-canvas-error');
            if (err) err.hidden = false;
        };
        bgTest.src = canvas.dataset.bgSrc;

        function applyFontScale(){
            const scale = canvas.getBoundingClientRect().width / bgWidth;
            tokens.forEach(token => {
                const original = parseFloat(token.dataset.fontsize) || 16;
                token.style.fontSize = Math.max(6, original * scale) + 'px';
            });
        }
        applyFontScale();
        requestAnimationFrame(applyFontScale);
        window.addEventListener('resize', applyFontScale);

        let dragging = null;
        tokens.forEach(token => {
            token.addEventListener('pointerdown', e => {
                dragging = token;
                token.classList.add('dragging');
                token.setPointerCapture(e.pointerId);
                highlightRow(token.dataset.index);
            });
            token.addEventListener('pointermove', e => {
                if (dragging !== token) return;
                const rect = canvas.getBoundingClientRect();
                let x = ((e.clientX - rect.left) / rect.width) * 100;
                let y = ((e.clientY - rect.top) / rect.height) * 100;
                x = Math.max(0, Math.min(100, x));
                y = Math.max(0, Math.min(100, y));
                token.style.left = x + '%';
                token.style.top = y + '%';
                token.dataset.x = x.toFixed(2);
                token.dataset.y = y.toFixed(2);
            });
            token.addEventListener('pointerup', e => {
                if (dragging === token) {
                    token.classList.remove('dragging');
                    token.releasePointerCapture(e.pointerId);
                    dragging = null;
                }
            });
            token.addEventListener('click', () => highlightRow(token.dataset.index));
        });

        function highlightRow(index){
            rows.forEach(r => r.classList.toggle('active', r.dataset.index === index));
            const row = rows.find(r => r.dataset.index === index);
            if (row) row.scrollIntoView({block:'nearest', behavior:'smooth'});
        }

        rows.forEach(row => {
            const idx = row.dataset.index;
            const token = tokens.find(t => t.dataset.index === idx);
            if (!token) return;

            const fontsize = row.querySelector('.f-fontsize');
            const color = row.querySelector('.f-color');
            const align = row.querySelector('.f-align');
            const bold = row.querySelector('.f-bold');
            const visible = row.querySelector('.f-visible');

            fontsize?.addEventListener('input', () => {
                token.dataset.fontsize = fontsize.value;
                applyFontScale();
            });
            color?.addEventListener('input', () => token.style.color = color.value);
            align?.addEventListener('change', () => {
                token.classList.remove('align-left','align-center','align-right');
                token.classList.add('align-' + align.value);
                token.style.textAlign = align.value;
            });
            bold?.addEventListener('change', () => token.style.fontWeight = bold.checked ? '700' : '400');
            visible?.addEventListener('change', () => token.classList.toggle('is-hidden', !visible.checked));

            const valueInput = row.querySelector('.f-value');
            const sampleSpan = token.querySelector('.cert-token-sample');
            valueInput?.addEventListener('input', () => {
                if (sampleSpan) sampleSpan.textContent = valueInput.value || row.querySelector('b').textContent.trim();
            });
        });

        form.addEventListener('submit', () => {
            holder.innerHTML = '';
            rows.forEach(row => {
                const idx = row.dataset.index;
                const token = tokens.find(t => t.dataset.index === idx);
                const key = token.dataset.key;
                const label = row.querySelector('b').textContent.trim();
                const kind = row.querySelector('.f-remove-form') ? 'custom' : 'dynamic';
                const valueInput = row.querySelector('.f-value');
                const x = token.dataset.x || parseFloat(token.style.left);
                const y = token.dataset.y || parseFloat(token.style.top);

                const fieldsMap = {
                    key, label, kind,
                    x, y,
                    font_size: row.querySelector('.f-fontsize').value,
                    color: row.querySelector('.f-color').value,
                    align: row.querySelector('.f-align').value,
                    bold: row.querySelector('.f-bold').checked ? 1 : 0,
                    visible: row.querySelector('.f-visible').checked ? 1 : 0,
                    value: valueInput ? valueInput.value : '',
                };

                Object.entries(fieldsMap).forEach(([name, val]) => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = `fields[${idx}][${name}]`;
                    input.value = val;
                    holder.appendChild(input);
                });

                const sourceInput = document.createElement('input');
                sourceInput.type = 'hidden';
                sourceInput.name = `fields[${idx}][source]`;
                sourceInput.value = token.dataset.source || '';
                holder.appendChild(sourceInput);
            });
        });
    })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/admin/certificate/edit.blade.php ENDPATH**/ ?>