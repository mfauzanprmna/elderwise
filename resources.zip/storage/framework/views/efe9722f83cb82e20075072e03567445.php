<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-5 md:px-10 py-10 md:py-14">

        <div class="flex flex-wrap justify-between items-end gap-6 mb-6">
            <div>
                <div class="eyebrow">Admin · Materi</div>
                <h1 class="text-3xl md:text-4xl mt-2 mb-1">Materi & Submodul</h1>
                <p class="text-muted text-lg m-0">Quiz bersifat opsional. Isi materi dapat berupa editor teks atau PDF.</p>
            </div>
            <a class="btn btn-primary" href="<?php echo e(route('admin.lessons.create', $selectedModule ? ['module' => $selectedModule] : [])); ?>">+ Tambah Materi</a>
        </div>


        <form method="GET" class="mb-5">
            <label class="form-label max-w-sm">
                Modul
                <select name="module" onchange="this.form.submit()" class="form-input">
                    <option value="">Semua Modul</option>
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($module->id); ?>" <?php if((string) $selectedModule === (string) $module->id): echo 'selected'; endif; ?>>
                            Modul <?php echo e($module->number); ?> — <?php echo e($module->title); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
        </form>

        <div class="card overflow-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr>
                        <th class="text-left px-4 py-4 border-b border-line font-extrabold text-navy" style="background:#f5f9ff">Kode</th>
                        <th class="text-left px-4 py-4 border-b border-line font-extrabold text-navy" style="background:#f5f9ff">Materi</th>
                        <th class="text-left px-4 py-4 border-b border-line font-extrabold text-navy" style="background:#f5f9ff">Jenis</th>
                        <th class="text-left px-4 py-4 border-b border-line font-extrabold text-navy" style="background:#f5f9ff">Quiz</th>
                        <th class="text-left px-4 py-4 border-b border-line font-extrabold text-navy" style="background:#f5f9ff">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-4 border-b border-line"><strong><?php echo e($lesson->code); ?></strong></td>
                        <td class="px-4 py-4 border-b border-line">
                            <strong class="block"><?php echo e($lesson->title); ?></strong>
                            <small class="block text-muted mt-1">Modul <?php echo e($lesson->module->number); ?> · <?php echo e($lesson->module->title); ?></small>
                        </td>
                        <td class="px-4 py-4 border-b border-line"><?php echo e($lesson->type === 'pdf' ? 'PDF' : 'Teks'); ?></td>
                        <td class="px-4 py-4 border-b border-line"><?php echo e($lesson->quiz ? 'Ada' : 'Tidak'); ?></td>
                        <td class="px-4 py-4 border-b border-line">
                            <div class="flex items-center gap-2.5">
                                <a class="btn btn-ghost btn-sm" href="<?php echo e(route('admin.lessons.edit', $lesson)); ?>">Edit</a>
                                <form method="POST" action="<?php echo e(route('admin.lessons.destroy', $lesson)); ?>" onsubmit="return confirm('Hapus materi ini?')" class="m-0">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-center text-muted py-11">Belum ada materi pada modul ini.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/admin/lessons/index.blade.php ENDPATH**/ ?>