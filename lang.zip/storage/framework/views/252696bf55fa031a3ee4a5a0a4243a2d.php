<?php $__env->startSection('content'); ?>
    <div class="min-h-[calc(100vh-84px)] grid place-items-center px-5 py-12">
        <div class="card w-full max-w-md p-9 md:p-11">
            <div class="eyebrow">Welcome Back</div>
            <h1 class="text-3xl mt-2 mb-2">Masuk ke <?php echo e($site->site_name); ?></h1>
            <p class="text-muted text-lg">Lanjutkan perjalanan digital Anda.</p>

            <div class="mt-7">
                <?php if (isset($component)) { $__componentOriginal5ae6345da0b49475aac6c124629b2dc1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ae6345da0b49475aac6c124629b2dc1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.google-auth','data' => ['label' => 'Masuk dengan Google']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('google-auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Masuk dengan Google']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ae6345da0b49475aac6c124629b2dc1)): ?>
<?php $attributes = $__attributesOriginal5ae6345da0b49475aac6c124629b2dc1; ?>
<?php unset($__attributesOriginal5ae6345da0b49475aac6c124629b2dc1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ae6345da0b49475aac6c124629b2dc1)): ?>
<?php $component = $__componentOriginal5ae6345da0b49475aac6c124629b2dc1; ?>
<?php unset($__componentOriginal5ae6345da0b49475aac6c124629b2dc1); ?>
<?php endif; ?>
            </div>

            <form method="POST" action="<?php echo e(route('login.store')); ?>" class="grid gap-5">
                <?php echo csrf_field(); ?>
                <label class="form-label">
                    Email
                    <input class="form-input" name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="email">
                </label>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red text-sm font-semibold"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="form-label">
                    Kata sandi
                    <input class="form-input" name="password" type="password" required autocomplete="current-password">
                </label>

                <div class="flex items-center justify-between gap-4 flex-wrap">
                    <label class="flex items-center gap-2.5 font-semibold text-lg">
                        <input type="checkbox" name="remember" class="w-5.5 h-5.5">
                        Ingat saya
                    </label>
                    <a class="text-blue-dark font-bold text-lg underline" href="<?php echo e(route('password.request')); ?>">Lupa kata sandi?</a>
                </div>

                <button class="btn btn-primary w-full" data-loading-text="Sedang masuk…">Masuk</button>
            </form>

            <p class="text-center text-muted mt-6 mb-0 text-lg">
                Belum punya akun?
                <a class="text-blue-dark font-bold" href="<?php echo e(route('register')); ?>">Daftar sekarang</a>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/auth/login.blade.php ENDPATH**/ ?>