<?php
namespace App\Http\Controllers;

use App\Models\Module;
use App\Models\Lesson;
use Illuminate\Support\Facades\Auth;

class LearningController extends Controller
{
    public function landing(){ return view('home'); }

    public function dashboard(){
        $modules=Module::with('lessons')->orderBy('sort_order')->get();
        $completed=Auth::user()->lessonProgress()->whereNotNull('completed_at')->pluck('lesson_id')->all();
        $total=$modules->sum(fn($m)=>$m->lessons->count()); $done=count($completed);
        $allCompleted = $total > 0 && $done === $total;
        $certificate = Auth::user()->certificate;

        $totalXp = (int) Auth::user()->lessonProgress()->whereNotNull('completed_at')->sum('xp');
        $modulesCompletedCount = $modules->filter(function ($m) use ($completed) {
            $ids = $m->lessons->pluck('id')->all();
            return count($ids) > 0 && count(array_diff($ids, $completed)) === 0;
        })->count();
        $rank = $this->rankForXp($totalXp);

        return view('learning.dashboard', compact(
            'modules','completed','total','done','allCompleted','certificate',
            'totalXp','modulesCompletedCount','rank'
        ));
    }

    /**
     * Sistem rank sederhana berbasis total XP yang terkumpul.
     * Setiap lesson biasa = 1 XP, lesson dengan quiz lulus = 3 XP.
     */
    private function rankForXp(int $xp): array
    {
        $ranks = [
            ['name' => 'Pemula Digital',     'min' => 0,   'icon' => '🌱'],
            ['name' => 'Penjelajah Digital',  'min' => 15,  'icon' => '🧭'],
            ['name' => 'Digital Explorer',    'min' => 35,  'icon' => '⭐'],
            ['name' => 'Digital Achiever',    'min' => 60,  'icon' => '🏅'],
            ['name' => 'ElderWiSE Master',    'min' => 90,  'icon' => '👑'],
        ];

        $current = $ranks[0];
        $next = null;
        foreach ($ranks as $i => $r) {
            if ($xp >= $r['min']) {
                $current = $r;
                $next = $ranks[$i + 1] ?? null;
            }
        }

        $progressPct = 100;
        if ($next) {
            $span = $next['min'] - $current['min'];
            $progressPct = $span > 0 ? min(100, round((($xp - $current['min']) / $span) * 100)) : 100;
        }

        return [
            'name' => $current['name'],
            'icon' => $current['icon'],
            'next_name' => $next['name'] ?? null,
            'next_min' => $next['min'] ?? null,
            'progress_pct' => $progressPct,
        ];
    }

    public function show(Module $module, Lesson $lesson=null){
        $modules=Module::with('lessons')->orderBy('sort_order')->get();
        $module->load('lessons');
        if($lesson && $lesson->module_id !== $module->id) abort(404);
        $lesson ??= $module->lessons->first();
        $completed=Auth::user()->lessonProgress()->whereNotNull('completed_at')->pluck('lesson_id')->all();
        return view('learning.show', compact('module','lesson','completed','modules'));
    }
}
