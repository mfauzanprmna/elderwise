Verifikasi email Anda di <?php echo $namaSitus; ?>


Terima kasih sudah mendaftar. Agar akun Anda aktif dan dapat mulai belajar, mohon pastikan bahwa alamat email ini benar milik Anda.

Buka alamat berikut untuk memverifikasi email:
<?php echo $url; ?>


Tautan ini berlaku selama <?php echo e($menit); ?> menit. Jika sudah kedaluwarsa, Anda dapat meminta tautan baru dari halaman verifikasi setelah masuk.

Jika Anda tidak merasa mendaftar, abaikan saja email ini.
<?php /**PATH D:\Project\elderwise-laravel12\resources\views/emails/verify-email-text.blade.php ENDPATH**/ ?>