@extends('layouts.app')
@section('hide_footer', '1')
@section('content')
    <div class="grid grid-cols-1 md:grid-cols-[360px_1fr] h-[calc(100vh-84px)] md:h-[calc(100vh-84px)] overflow-hidden">

        {{-- ===================== KIRI: PETA BELAJAR (semua modul & sub-modul) ===================== --}}
        <aside class="bg-white border-b-2 md:border-b-0 md:border-r-2 border-line overflow-auto max-h-[46vh] md:max-h-none">
            <div class="px-6 pt-6 pb-4 border-b-2 border-line">
                <div class="eyebrow">{{ $site->site_name }}</div>
                <h2 class="text-xl mt-1 mb-3">Peta Belajar</h2>
                <div class="text-navy text-sm font-semibold">
                    <span>{{ collect($completed)->count() }} selesai</span>
                    <div class="h-2 bg-blue-tint rounded-full mt-2 overflow-hidden">
                        <div class="h-full bg-blue rounded-full" style="width:{{ max(5, min(100, count($completed) * 4)) }}%"></div>
                    </div>
                </div>
            </div>

            <div class="p-2.5">
                @foreach($modules as $m)
                    @php
                        $moduleLessonIds = $m->lessons->pluck('id')->all();
                        $moduleDone = count(array_intersect($moduleLessonIds, $completed));
                        $modulePct = count($moduleLessonIds) ? round($moduleDone / count($moduleLessonIds) * 100) : 0;
                        $isOpen = $module->id === $m->id;
                    @endphp
                    <div class="p-1.5">
                        <a href="{{ route('learning.show', $m) }}"
                           class="flex items-center gap-3 px-3 py-3.5 rounded-xl no-underline text-base {{ $isOpen ? 'bg-blue-tint text-blue-dark font-extrabold' : 'text-navy hover:bg-blue-50' }}">
                            <span class="relative w-[38px] h-[38px] rounded-full grid place-items-center shrink-0"
                                  style="background:conic-gradient(var(--color-blue) {{ $modulePct }}%, var(--color-blue-tint) 0)">
                                <span class="absolute w-[28px] h-[28px] bg-white rounded-full"></span>
                                <span class="relative text-[9px] font-extrabold text-blue-dark">{{ $modulePct }}%</span>
                            </span>
                            <span class="flex-1 min-w-0">
                                <b class="block">Modul {{ $m->number }}</b>
                                <span class="block text-sm font-normal truncate">{{ $m->title }}</span>
                            </span>
                        </a>

                        @if($isOpen)
                            <div class="pl-3.5 pt-1.5 pb-2">
                                @foreach($m->lessons as $l)
                                    @php
                                        $isCurrent = $lesson?->id === $l->id;
                                        $isDone = in_array($l->id, $completed);
                                    @endphp
                                    <a href="{{ route('learning.show', [$m, $l]) }}"
                                       class="flex items-center gap-3 no-underline px-2.5 py-3 rounded-xl text-base leading-snug
                                              {{ $isCurrent ? 'bg-blue-tint text-blue-dark font-bold shadow-[inset_3px_0_0_var(--color-blue)]' : 'text-ink hover:bg-blue-50' }}">
                                        <span class="min-w-[34px] h-[34px] rounded-full grid place-items-center text-[11px] font-extrabold shrink-0
                                                      {{ $isDone ? 'bg-green-tint text-green text-base' : 'bg-blue-tint/60 text-navy' }}">
                                            {{ $isDone ? '✓' : $l->code }}
                                        </span>
                                        <span>{{ $l->title }}</span>
                                    </a>
                                @endforeach
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
        </aside>

        {{-- ===================== KANAN: ISI MATERI SUB-MODUL ===================== --}}
        <section class="overflow-auto bg-bg px-5 md:px-[5vw] pt-9 pb-16">
            <div class="flex flex-wrap justify-between gap-2.5 text-navy text-base font-semibold">
                <a href="{{ route('dashboard') }}" class="text-blue-dark no-underline font-bold hover:underline">← Dashboard</a>
                <span>Modul {{ $module->number }} · {{ $module->title }}</span>
            </div>

            @if($lesson)
                <div class="max-w-3xl mx-auto mt-8 mb-6">
                    <div class="eyebrow">{{ $lesson->code }}</div>
                    <h1 class="text-3xl md:text-4xl mt-2 mb-2">{{ $lesson->title }}</h1>
                    <p class="text-ink text-lg">{{ $module->slogan }}</p>
                </div>

                <div class="max-w-4xl mx-auto card overflow-hidden">
                    @if($lesson->type === 'pdf' && $lesson->pdf_path)
                        <iframe class="block w-full h-[70vh] border-0" src="{{ Storage::url($lesson->pdf_path) }}"></iframe>
                    @else
                        <div class="lesson-prose p-8 md:p-10 text-lg leading-[1.75] max-w-none">{!! $lesson->renderedContent() !!}</div>
                    @endif

                    @if($lesson->quiz)
                        <div class="m-6 md:m-8 mt-0 bg-blue-50 border-2 border-line rounded-2xl p-7" style="background:#f2f7fc">
                            <div class="eyebrow">Checkpoint</div>
                            <h2 class="text-2xl mt-1 mb-5">Sudah bisa?</h2>
                            <form method="POST" action="{{ route('learning.quiz', $lesson) }}">
                                @csrf
                                @foreach($lesson->quiz as $i => $q)
                                    <div class="my-6">
                                        <h3 class="text-lg text-navy font-bold mb-2">{{ $i + 1 }}. {{ $q['question'] }}</h3>
                                        @foreach($q['options'] as $oi => $opt)
                                            <label class="flex items-center gap-3 bg-white px-4 py-3.5 border-2 border-line rounded-xl my-2.5 font-semibold text-base cursor-pointer hover:border-blue">
                                                <input type="radio" name="answers[{{ $i }}]" value="{{ $oi }}" required class="w-5.5 h-5.5 shrink-0">
                                                <span>{{ $opt }}</span>
                                            </label>
                                        @endforeach
                                    </div>
                                @endforeach
                                <button class="btn btn-primary mt-2">Periksa Jawaban</button>
                            </form>

                            @if(session('quiz_result'))
                                @php $passed = session('quiz_result.passed'); @endphp
                                <div class="mt-5 px-5 py-4 rounded-xl text-lg font-semibold {{ $passed ? 'bg-green-tint text-green' : 'bg-amber-tint text-amber' }}">
                                    Skor Anda: <b>{{ session('quiz_result.score') }}/{{ session('quiz_result.total') }}</b>.
                                    {{ $passed ? 'Materi ini tercatat selesai!' : 'Coba lagi pelan-pelan.' }}
                                </div>
                            @endif
                        </div>
                    @endif
                </div>

                <div class="max-w-4xl mx-auto mt-6 text-right">
                    @if(in_array($lesson->id, $completed))
                        <div class="inline-block px-5 py-3.5 rounded-xl bg-green-tint text-green font-extrabold text-lg">✓ Lesson selesai</div>
                    @else
                        <form method="POST" action="{{ route('learning.complete', $lesson) }}">
                            @csrf
                            <button class="btn btn-primary">Tandai selesai →</button>
                        </form>
                    @endif
                </div>
            @else
                <div class="text-center py-24 px-5">
                    <h2 class="text-2xl">Pilih materi untuk mulai.</h2>
                </div>
            @endif
        </section>
    </div>
@endsection
