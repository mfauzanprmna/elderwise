<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['site', 'size' => 44]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['site', 'size' => 44]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<span <?php echo e($attributes->merge(['class' => 'flex items-center gap-3 min-w-0'])); ?>>
    <?php if($site->logoUrl()): ?>
        <img src="<?php echo e($site->logoUrl()); ?>" alt="<?php echo e($site->site_name); ?>" class="w-auto object-contain shrink-0"
             style="height:<?php echo e($size); ?>px;max-width:<?php echo e($size * 4); ?>px">
    <?php else: ?>
        <span class="grid place-items-center rounded-xl bg-blue text-white font-extrabold shrink-0"
              style="width:<?php echo e($size); ?>px;height:<?php echo e($size); ?>px;font-size:<?php echo e(round($size * 0.45)); ?>px" aria-hidden="true"><?php echo e($site->initial()); ?></span>
    <?php endif; ?>
    <?php if(! $site->logoUrl() || $site->show_name_with_logo): ?>
        <span class="font-extrabold text-navy leading-tight truncate"><?php echo e($site->site_name); ?></span>
    <?php endif; ?>
</span>
<?php /**PATH D:\Project\elderwise-laravel12\resources\views/components/brand.blade.php ENDPATH**/ ?>