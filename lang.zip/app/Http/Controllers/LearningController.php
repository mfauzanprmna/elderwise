<?php
namespace App\Http\Controllers;

use App\Models\Module;
use App\Models\Lesson;
use App\Models\LessonProgress;
use App\Support\LearningPath;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class LearningController extends Controller
{
    public function landing(){ return view('home'); }

    public function dashboard(){
        $path = new LearningPath(Auth::user());
        $modules = $path->modules;
        $completed = $path->completedIds();
        $total = $path->totalCount(); $done = $path->completedCount();
        $allCompleted = $total > 0 && $done === $total;
        $certificate = Auth::user()->certificate;

        $totalXp = (int) Auth::user()->lessonProgress()->whereNotNull('completed_at')->sum('xp');
        $modulesCompletedCount = $modules->filter(fn ($m) => $path->isModuleComplete($m))->count();
        $rank = $this->rankForXp($totalXp);

        return view('learning.dashboard', compact(
            'modules','completed','total','done','allCompleted','certificate',
            'totalXp','modulesCompletedCount','rank','path'
        ));
    }

    /**
     * Sistem rank sederhana berbasis total XP yang terkumpul.
     * Setiap lesson biasa = 1 XP, lesson dengan quiz lulus = 3 XP.
     */
    private function rankForXp(int $xp): array
    {
        $ranks = [
            ['name' => 'Pemula Digital',     'min' => 0,   'icon' => '🌱'],
            ['name' => 'Penjelajah Digital',  'min' => 15,  'icon' => '🧭'],
            ['name' => 'Digital Explorer',    'min' => 35,  'icon' => '⭐'],
            ['name' => 'Digital Achiever',    'min' => 60,  'icon' => '🏅'],
            ['name' => 'ElderWiSE Master',    'min' => 90,  'icon' => '👑'],
        ];

        $current = $ranks[0];
        $next = null;
        foreach ($ranks as $i => $r) {
            if ($xp >= $r['min']) {
                $current = $r;
                $next = $ranks[$i + 1] ?? null;
            }
        }

        $progressPct = 100;
        if ($next) {
            $span = $next['min'] - $current['min'];
            $progressPct = $span > 0 ? min(100, round((($xp - $current['min']) / $span) * 100)) : 100;
        }

        return [
            'name' => $current['name'],
            'icon' => $current['icon'],
            'next_name' => $next['name'] ?? null,
            'next_min' => $next['min'] ?? null,
            'progress_pct' => $progressPct,
        ];
    }

    public function show(Module $module, ?Lesson $lesson = null){
        $user = Auth::user();
        $path = new LearningPath($user);

        if (! $lesson) {
            // Masuk lewat modul: arahkan ke materi yang belum selesai pertama (atau yang pertama).
            if (! $path->isModuleUnlocked($module)) {
                return $this->redirectToFrontier($path, 'Modul ini masih terkunci. Selesaikan modul sebelumnya terlebih dahulu, ya.');
            }
            $resume = $path->resumeLessonFor($module);
            if ($resume) {
                return redirect()->route('learning.show', [$module->id, $resume->id]);
            }
        } else {
            abort_if($lesson->module_id !== $module->id, 404);
            if (! $path->isUnlocked($lesson)) {
                return $this->redirectToFrontier($path, 'Materi ini masih terkunci. Selesaikan materi sebelumnya terlebih dahulu, ya.');
            }
        }

        $plan = ['mode' => 'text', 'html' => '', 'sections' => []];
        $progress = null; $total = 0; $reached = 0; $completedThis = false; $readingDone = false;
        $moduleCompleted = null; $autoCompleted = false;

        if ($lesson) {
            $plan = $lesson->readingPlan();
            $total = count($plan['sections']);

            $progress = LessonProgress::firstOrCreate(
                ['user_id' => $user->id, 'lesson_id' => $lesson->id],
                ['checkpoint' => 0]
            );
            $completedThis = (bool) $progress->completed_at;

            if (! $completedThis) {
                // Titik awal hitungan waktu baca di sisi server = saat halaman ini dibuka.
                $progress->checkpoint_at = now();

                // Tanpa kuis dan tidak ada lagi yang perlu dibaca (materi kosong, atau semua bagian sudah dilewati
                // sebelum materinya diubah): selesai otomatis agar peserta tidak tertahan di urutan belajar.
                if (! $lesson->hasQuiz() && (int) $progress->checkpoint >= $total) {
                    $progress->completed_at = now();
                    $progress->xp = 1;
                    $completedThis = true;
                    $autoCompleted = true;
                }
            }
            $progress->save();

            if ($autoCompleted) {
                $path = new LearningPath($user); // segarkan status
                $m = $path->moduleOf($lesson);
                if ($m && $path->isModuleComplete($m)) {
                    $moduleCompleted = $path->moduleCompletionPayload($m);
                }
            }

            $reached = $completedThis ? $total : min((int) $progress->checkpoint, $total);
            $readingDone = $completedThis || $reached >= $total;
        }

        $prevLesson = $lesson ? $path->previous($lesson) : null;
        $nextLesson = $lesson ? $path->next($lesson) : null;
        $nextModule = $nextLesson ? $path->moduleOf($nextLesson) : null;
        $nextUnlocked = $nextLesson ? $path->isUnlocked($nextLesson) : true;
        $completed = $path->completedIds();
        $modules = $path->modules;

        return view('learning.show', compact(
            'module','lesson','completed','modules','path','plan','total','reached','completedThis','readingDone',
            'moduleCompleted','prevLesson','nextLesson','nextModule','nextUnlocked'
        ));
    }

    /** Arahkan peserta ke posisi belajarnya saat ini ketika ia mencoba membuka materi/modul yang masih terkunci. */
    private function redirectToFrontier(LearningPath $path, string $message): RedirectResponse
    {
        $target = $path->frontier();

        if (! $target) {
            return redirect()->route('dashboard')->with('locked_notice', $message);
        }

        return redirect()->route('learning.show', [$target->module_id, $target->id])->with('locked_notice', $message);
    }
}
