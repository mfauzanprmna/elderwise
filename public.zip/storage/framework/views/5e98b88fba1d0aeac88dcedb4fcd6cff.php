<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <?php if(filled($site->description)): ?>
        <meta name="description" content="<?php echo e($site->description); ?>">
    <?php endif; ?>
    <title><?php echo e($title ?? $site->site_name); ?></title>
    <?php if($site->faviconUrl() ?? $site->logoUrl()): ?>
        <link rel="icon" href="<?php echo e($site->faviconUrl() ?? $site->logoUrl()); ?>">
    <?php endif; ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <a href="#konten-utama" class="skip-link">Langsung ke konten</a>

    <nav class="sticky top-0 z-50 h-20 md:h-[84px] bg-white border-b-2 border-line flex items-center justify-between gap-4 px-5 md:px-[5vw]">
        <a class="no-underline text-xl md:text-2xl min-w-0" href="<?php echo e(route('home')); ?>">
            <?php if (isset($component)) { $__componentOriginal6328f0deb07a8bef5ad2cd5691beb925 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6328f0deb07a8bef5ad2cd5691beb925 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.brand','data' => ['site' => $site]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['site' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($site)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6328f0deb07a8bef5ad2cd5691beb925)): ?>
<?php $attributes = $__attributesOriginal6328f0deb07a8bef5ad2cd5691beb925; ?>
<?php unset($__attributesOriginal6328f0deb07a8bef5ad2cd5691beb925); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6328f0deb07a8bef5ad2cd5691beb925)): ?>
<?php $component = $__componentOriginal6328f0deb07a8bef5ad2cd5691beb925; ?>
<?php unset($__componentOriginal6328f0deb07a8bef5ad2cd5691beb925); ?>
<?php endif; ?>
        </a>
        <div class="flex items-center gap-4 md:gap-5 shrink-0">
            <?php if(auth()->guard()->check()): ?>
                <a class="text-navy no-underline font-bold text-base md:text-lg hover:text-blue" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <a class="text-navy no-underline font-bold text-base md:text-lg hover:text-blue" href="<?php echo e(route('admin.dashboard')); ?>">Admin</a>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="m-0">
                    <?php echo csrf_field(); ?>
                    <button class="border-0 bg-transparent text-navy font-bold text-base md:text-lg cursor-pointer hover:text-blue">Keluar</button>
                </form>
            <?php else: ?>
                <a class="text-navy no-underline font-bold text-base md:text-lg hover:text-blue" href="<?php echo e(route('login')); ?>">Masuk</a>
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('register')); ?>">Daftar</a>
            <?php endif; ?>
        </div>
    </nav>

    <?php if(session('success')): ?>
        <div data-toast class="fixed right-5 top-24 z-[100] flex items-center gap-2 bg-green-tint text-green border-2 border-green/30 rounded-xl px-5 py-4 font-semibold text-base shadow-elder">
            <span>✓</span> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <main id="konten-utama">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php if((filled($site->footer_text) || $sitePartners->isNotEmpty()) && ! View::hasSection('hide_footer')): ?>
        <footer class="bg-white border-t-2 border-line px-5 py-8 text-center">
            <?php if($sitePartners->isNotEmpty()): ?>
                <p class="text-sm font-extrabold tracking-wider text-muted uppercase mb-4">Diselenggarakan oleh</p>
                <div class="flex flex-wrap items-center justify-center gap-x-10 gap-y-4 mb-6">
                    <?php $__currentLoopData = $sitePartners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($partner->url): ?><a href="<?php echo e($partner->url); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo e($partner->name); ?>"><?php endif; ?>
                        <img src="<?php echo e($partner->logoUrl()); ?>" alt="<?php echo e($partner->name); ?>" class="h-16 md:h-24 w-auto max-w-[260px] object-contain">
                        <?php if($partner->url): ?></a><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(filled($site->footer_text)): ?>
                <p class="text-muted text-base m-0 max-w-3xl mx-auto"><?php echo e($site->footer_text); ?></p>
            <?php endif; ?>
        </footer>
    <?php endif; ?>

    <script>setTimeout(function () { document.querySelectorAll('[data-toast]').forEach(function (el) { el.remove(); }); }, 5000);</script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Project\elderwise-laravel12\resources\views/layouts/app.blade.php ENDPATH**/ ?>