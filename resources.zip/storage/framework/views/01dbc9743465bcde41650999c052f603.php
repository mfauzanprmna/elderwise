<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
    @page { margin: 0; }
    html, body { margin:0; padding:0; }
    .sheet {
        position: relative;
        width: 297mm;   /* A4 landscape */
        height: 210mm;
        overflow: hidden;
    }
    .sheet img.bg {
        position: absolute;
        top: 0; left: 0;
        width: 297mm;
        height: 210mm;
    }
    .field {
        position: absolute;
        font-family: DejaVu Sans, sans-serif;
        white-space: nowrap;
        transform: translateY(-50%);
    }
    .align-center { text-align: center; transform: translate(-50%,-50%); }
    .align-left { text-align: left; }
    .align-right { text-align: right; transform: translate(-100%,-50%); }

    /* ===== Halaman 2: rincian materi ===== */
    .sheet-2 { page-break-before: always; height: 209mm; background: #ffffff; }
    .panel {
        position: absolute;
        left: 6%; top: 6%;
        width: 88%; height: 88%;
        background: #ffffff;
        font-family: DejaVu Sans, sans-serif;
        color: #16233a;
    }
    .panel-inner { padding: 16px 28px; }
    .t-title { text-align: center; font-size: 20px; font-weight: 700; color: #0f2f52; margin: 0 0 2px; }
    .t-sub { text-align: center; font-size: 11px; color: #41546c; margin: 0 0 10px; }
    table.t-info { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
    table.t-info td { font-size: 11px; padding: 1px 0; }
    table.t-main { width: 100%; border-collapse: collapse; table-layout: fixed; }
    table.t-main th { background: #0f2f52; color: #ffffff; font-size: 11px; text-align: left; padding: 6px 8px; }
    table.t-main td { border-bottom: 1px solid #c9d6e6; padding: 4px 8px; vertical-align: top; }
    table.t-main tr.t-total td { border-top: 2px solid #0f2f52; border-bottom: none; font-weight: 700; background: #f4f7fb; }
    .t-note { font-size: 10px; color: #41546c; margin-top: 8px; }
</style>
</head>
<body>
<div class="sheet">
    <?php if($backgroundPath && file_exists($backgroundPath)): ?>
        <img class="bg" src="<?php echo e($backgroundPath); ?>">
    <?php endif; ?>

    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($f['visible'] ?? true)): ?>
            <?php
                $text = match($f['source'] ?? null) {
                    'user_name' => $values['user_name'],
                    'issued_date' => $values['issued_date'],
                    'certificate_number' => $values['certificate_number'],
                    default => $f['value'] ?? '',
                };
                if (empty($text) && ($f['source'] ?? null) === 'program_name') {
                    $text = $f['value'] ?? '';
                }
                $alignClass = match($f['align'] ?? 'center') {
                    'left' => 'align-left',
                    'right' => 'align-right',
                    default => 'align-center',
                };
            ?>
            <?php if(filled($text)): ?>
                <div class="field <?php echo e($alignClass); ?>"
                     style="left:<?php echo e($f['x']); ?>%; top:<?php echo e($f['y']); ?>%;
                            font-size:<?php echo e($f['font_size'] ?? 16); ?>px;
                            color:<?php echo e($f['color'] ?? '#15304d'); ?>;
                            font-weight:<?php echo e(!empty($f['bold']) ? '700' : '400'); ?>;">
                    <?php echo e($text); ?>

                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if(!empty($transcript)): ?>
<?php $fs = $transcript['font_px']; ?>
<div class="sheet sheet-2">
    <div class="panel">
        <div class="panel-inner">
            <p class="t-title">Rincian Materi Pelatihan</p>
            <p class="t-sub"><?php echo e($setting->title ?: 'Sertifikat Kelulusan'); ?></p>

            <table class="t-info">
                <tr>
                    <td style="width:46%"><b>Nama</b> : <?php echo e($values['user_name']); ?></td>
                    <td style="width:30%"><b>No. Sertifikat</b> : <?php echo e($values['certificate_number']); ?></td>
                    <td style="width:24%; text-align:right"><b>Tanggal</b> : <?php echo e($values['issued_date']); ?></td>
                </tr>
            </table>

            <table class="t-main">
                <thead>
                    <tr>
                        <th style="width:6%">No</th>
                        <th style="width:26%">Modul</th>
                        <th style="width:58%">Materi yang Dipelajari</th>
                        <th style="width:10%; text-align:center">JP</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $transcript['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size:<?php echo e($fs); ?>px"><?php echo e($i + 1); ?></td>
                        <td style="font-size:<?php echo e($fs); ?>px"><b><?php echo e($row['title']); ?></b><?php if($row['slogan']): ?><br><span style="font-size:<?php echo e(max(8, $fs - 2)); ?>px; color:#41546c"><?php echo e($row['slogan']); ?></span><?php endif; ?></td>
                        <td style="font-size:<?php echo e($fs); ?>px"><?php if($transcript['compact']): ?><?php echo e(count($row['topics'])); ?> materi <?php else: ?><?php echo e($row['topics'] ? implode(' • ', $row['topics']) : $row['description']); ?><?php endif; ?></td>
                        <td style="font-size:<?php echo e($fs); ?>px; text-align:center"><?php echo e($row['jp']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(($transcript['hidden_count'] ?? 0) > 0): ?>
                    <tr>
                        <td colspan="4" style="font-size:<?php echo e($fs); ?>px; color:#41546c; text-align:center">… dan <?php echo e($transcript['hidden_count']); ?> modul lainnya</td>
                    </tr>
                    <?php endif; ?>
                    <tr class="t-total">
                        <td colspan="3" style="font-size:<?php echo e($fs + 1); ?>px; text-align:right">Total Jam Pelatihan</td>
                        <td style="font-size:<?php echo e($fs + 1); ?>px; text-align:center"><?php echo e($transcript['total_jp']); ?> JP</td>
                    </tr>
                </tbody>
            </table>
            <p class="t-note">JP = Jam Pelatihan. Setiap modul dihitung 1 JP.</p>
        </div>
    </div>
</div>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\Project\elderwise-laravel12\resources\views\certificates\pdf.blade.php ENDPATH**/ ?>