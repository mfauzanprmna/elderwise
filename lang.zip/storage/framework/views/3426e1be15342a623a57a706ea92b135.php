<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-5 md:px-10 py-10 md:py-14">

        <div class="flex flex-wrap justify-between items-end gap-6 mb-8">
            <div>
                <div class="eyebrow">Admin · Pengguna</div>
                <h1 class="text-3xl md:text-4xl mt-2 mb-1">Kelola Pengguna</h1>
                <p class="text-lg text-ink m-0">Tambah akun, ubah data atau peran, reset kata sandi, dan lihat progres belajar tiap pengguna.</p>
            </div>
            <div class="flex flex-wrap gap-3">
                <a class="btn btn-primary" href="<?php echo e(route('admin.users.create')); ?>">+ Tambah Pengguna</a>
            </div>
        </div>

        <?php if(session('error')): ?>
            <div class="bg-red-tint text-red rounded-xl px-5 py-4 font-semibold text-lg mb-5"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="grid grid-cols-3 gap-4 mb-6 max-w-xl">
            <div class="card px-5 py-3"><span class="text-muted text-sm font-bold">Semua</span><strong class="block text-2xl text-navy"><?php echo e($countAll); ?></strong></div>
            <div class="card px-5 py-3"><span class="text-muted text-sm font-bold">Peserta</span><strong class="block text-2xl text-navy"><?php echo e($countLearners); ?></strong></div>
            <div class="card px-5 py-3"><span class="text-muted text-sm font-bold">Admin</span><strong class="block text-2xl text-navy"><?php echo e($countAdmins); ?></strong></div>
        </div>

        <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="flex flex-wrap items-end gap-4 mb-5">
            <label class="form-label flex-1 min-w-[240px]">
                Cari nama atau email
                <input type="search" name="q" value="<?php echo e($q); ?>" class="form-input" placeholder="Contoh: sutrisno">
            </label>
            <label class="form-label w-48">
                Peran
                <select name="role" class="form-input">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = \App\Http\Controllers\AdminUserController::ROLES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if($role === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <button class="btn btn-primary">Cari</button>
            <?php if($q !== '' || $role !== ''): ?>
                <a class="btn btn-ghost" href="<?php echo e(route('admin.users.index')); ?>">Reset</a>
            <?php endif; ?>
        </form>

        <div class="card overflow-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr>
                        <?php $__currentLoopData = ['Pengguna', 'Peran', 'Progres belajar', 'XP', 'Sertifikat', 'Aksi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="text-left px-4 py-4 border-b border-line font-extrabold text-navy whitespace-nowrap" style="background:#f5f9ff"><?php echo e($h); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $pct = $totalLessons > 0 ? round($u->done_count / $totalLessons * 100) : 0;
                        $isSelf = $u->id === auth()->id();
                    ?>
                    <tr>
                        <td class="px-4 py-4 border-b border-line">
                            <strong class="block"><?php echo e($u->name); ?><?php if($isSelf): ?> <span class="ml-1 text-xs font-extrabold text-blue-dark bg-blue-tint rounded-full px-2 py-0.5">Anda</span><?php endif; ?></strong>
                            <small class="block text-muted mt-0.5"><?php echo e($u->email); ?></small>
                        </td>
                        <td class="px-4 py-4 border-b border-line">
                            <span class="text-sm font-extrabold rounded-full px-3 py-1 <?php echo e($u->role === 'admin' ? 'bg-amber-tint text-amber' : 'bg-blue-tint text-blue-dark'); ?>">
                                <?php echo e(\App\Http\Controllers\AdminUserController::ROLES[$u->role] ?? ucfirst($u->role)); ?>

                            </span>
                        </td>
                        <td class="px-4 py-4 border-b border-line min-w-[170px]">
                            <span class="text-base font-semibold"><?php echo e($u->done_count); ?>/<?php echo e($totalLessons); ?> materi</span>
                            <div class="h-2 rounded-full bg-blue-tint overflow-hidden mt-1.5 max-w-[150px]">
                                <div class="h-full rounded-full bg-blue" style="width:<?php echo e($pct); ?>%"></div>
                            </div>
                        </td>
                        <td class="px-4 py-4 border-b border-line"><?php echo e((int) $u->xp_total); ?></td>
                        <td class="px-4 py-4 border-b border-line whitespace-nowrap">
                            <?php if($u->certificate): ?>
                                <span class="text-green font-bold">✓ Terbit</span>
                                <small class="block text-muted"><?php echo e($u->certificate->number); ?></small>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-4 border-b border-line">
                            <div class="flex items-center gap-2.5">
                                <a class="btn btn-ghost btn-sm" href="<?php echo e(route('admin.users.edit', $u)); ?>">Edit</a>
                                <?php if (! ($isSelf)): ?>
                                    <form method="POST" action="<?php echo e(route('admin.users.destroy', $u)); ?>" class="m-0"
                                          onsubmit="return confirm(<?php echo e(\Illuminate\Support\Js::from('Hapus pengguna ' . $u->name . ' beserta seluruh progres belajar dan sertifikatnya? Tindakan ini tidak bisa dibatalkan.')); ?>)">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm">Hapus</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="text-center text-muted py-11">Tidak ada pengguna yang cocok.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="flex flex-wrap items-center justify-between gap-4 mt-5">
            <span class="text-muted text-base">
                <?php if($users->total() > 0): ?>
                    Menampilkan <?php echo e($users->firstItem()); ?>–<?php echo e($users->lastItem()); ?> dari <?php echo e($users->total()); ?> pengguna
                <?php endif; ?>
            </span>
            <?php if($users->hasPages()): ?>
                <div class="flex items-center gap-3">
                    <?php if($users->onFirstPage()): ?>
                        <span class="btn btn-ghost btn-sm opacity-40 pointer-events-none">← Sebelumnya</span>
                    <?php else: ?>
                        <a class="btn btn-ghost btn-sm" href="<?php echo e($users->previousPageUrl()); ?>">← Sebelumnya</a>
                    <?php endif; ?>
                    <span class="font-semibold text-navy">Hal. <?php echo e($users->currentPage()); ?>/<?php echo e($users->lastPage()); ?></span>
                    <?php if($users->hasMorePages()): ?>
                        <a class="btn btn-ghost btn-sm" href="<?php echo e($users->nextPageUrl()); ?>">Berikutnya →</a>
                    <?php else: ?>
                        <span class="btn btn-ghost btn-sm opacity-40 pointer-events-none">Berikutnya →</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views/admin/users/index.blade.php ENDPATH**/ ?>