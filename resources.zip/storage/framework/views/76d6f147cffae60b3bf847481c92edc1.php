<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-5 md:px-10 py-10 md:py-14">

        <div class="flex flex-wrap justify-between items-end gap-6 mb-8">
            <div>
                <div class="eyebrow">Admin · Modul</div>
                <h1 class="text-3xl md:text-4xl mt-2 mb-1">Learning Map</h1>
                <p class="text-lg text-ink m-0">Tambah, edit, urutkan, atau hapus modul pembelajaran.</p>
            </div>
            <div class="flex flex-wrap gap-3">
                <a class="btn btn-primary" href="<?php echo e(route('admin.modules.create')); ?>">+ Tambah Modul</a>
            </div>
        </div>


        <div class="card overflow-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr>
                        <th class="text-left px-4 py-4 bg-blue-50 font-extrabold text-navy border-b border-line" style="background:#f5f9ff">No.</th>
                        <th class="text-left px-4 py-4 bg-blue-50 font-extrabold text-navy border-b border-line" style="background:#f5f9ff">Judul</th>
                        <th class="text-left px-4 py-4 bg-blue-50 font-extrabold text-navy border-b border-line" style="background:#f5f9ff">Slogan</th>
                        <th class="text-left px-4 py-4 bg-blue-50 font-extrabold text-navy border-b border-line" style="background:#f5f9ff">Badge</th>
                        <th class="text-left px-4 py-4 bg-blue-50 font-extrabold text-navy border-b border-line" style="background:#f5f9ff">Materi</th>
                        <th class="text-left px-4 py-4 bg-blue-50 font-extrabold text-navy border-b border-line" style="background:#f5f9ff">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-4 border-b border-line"><strong><?php echo e($module->number); ?></strong></td>
                        <td class="px-4 py-4 border-b border-line">
                            <strong class="block"><?php echo e($module->title); ?></strong>
                            <small class="block text-muted mt-1"><?php echo e($module->description); ?></small>
                        </td>
                        <td class="px-4 py-4 border-b border-line"><?php echo e($module->slogan); ?></td>
                        <td class="px-4 py-4 border-b border-line">
                            <div class="flex items-center gap-3">
                                <?php if (isset($component)) { $__componentOriginal050558fa169e8fab1a632431d1ec4e8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal050558fa169e8fab1a632431d1ec4e8a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge-medal','data' => ['module' => $module,'state' => 'done','size' => 40]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge-medal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['module' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($module),'state' => 'done','size' => 40]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal050558fa169e8fab1a632431d1ec4e8a)): ?>
<?php $attributes = $__attributesOriginal050558fa169e8fab1a632431d1ec4e8a; ?>
<?php unset($__attributesOriginal050558fa169e8fab1a632431d1ec4e8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal050558fa169e8fab1a632431d1ec4e8a)): ?>
<?php $component = $__componentOriginal050558fa169e8fab1a632431d1ec4e8a; ?>
<?php unset($__componentOriginal050558fa169e8fab1a632431d1ec4e8a); ?>
<?php endif; ?>
                                <span><?php echo e($module->badge ?: '—'); ?></span>
                            </div>
                        </td>
                        <td class="px-4 py-4 border-b border-line"><?php echo e($module->lessons_count); ?></td>
                        <td class="px-4 py-4 border-b border-line">
                            <div class="flex items-center gap-3.5">
                                <a class="text-blue-dark font-bold" href="<?php echo e(route('admin.modules.edit', $module)); ?>">Edit</a>
                                <form method="POST" action="<?php echo e(route('admin.modules.destroy', $module)); ?>" onsubmit="return confirm('Hapus modul ini beserta semua materinya?')" class="m-0">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="border-0 bg-transparent text-red font-bold cursor-pointer">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="text-center text-muted py-11">Belum ada modul.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\elderwise-laravel12\resources\views\admin\modules\index.blade.php ENDPATH**/ ?>