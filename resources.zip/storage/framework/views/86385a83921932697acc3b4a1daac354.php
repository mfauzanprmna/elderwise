Atur ulang kata sandi <?php echo $namaSitus; ?>


Halo, kami menerima permintaan untuk membuat kata sandi baru bagi akun Anda.

Buka alamat berikut untuk membuat kata sandi baru:
<?php echo $url; ?>


Tautan ini berlaku selama <?php echo e($menit); ?> menit dan hanya dapat dipakai satu kali.

Jika Anda tidak merasa meminta ini, abaikan saja email ini. Kata sandi Anda tidak akan berubah.
<?php /**PATH D:\Project\elderwise-laravel12\resources\views\emails\reset-password-text.blade.php ENDPATH**/ ?>